# v2.19.0 (Fri Oct 09 2026)

#### :nut_and_bolt: Dependencies

- Update dependencies [#5818](https://github.com/ghostery/adblocker/pull/5818) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.18.2 (Wed Aug 05 2026)

#### :bug: Bug Fix

- Upgrade dependencies ([@seia-soto](https://github.com/seia-soto))

#### :memo: Documentation

- fix(docs): closing tag mismatches [#5782](https://github.com/ghostery/adblocker/pull/5782) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Upgrade dependencies [#5776](https://github.com/ghostery/adblocker/pull/5776) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.18.1 (Wed Jul 01 2026)

#### :house: Internal

- internal: housekeeping with 2026 asset registration [#5740](https://github.com/ghostery/adblocker/pull/5740) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.18.0 (Thu Jun 04 2026)

#### :house: Internal

- chore: update dependencies [#5723](https://github.com/ghostery/adblocker/pull/5723) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump the development-dependencies group across 1 directory with 4 updates [#5701](https://github.com/ghostery/adblocker/pull/5701) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.17.2 (Tue May 19 2026)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump the development-dependencies group across 1 directory with 5 updates [#5692](https://github.com/ghostery/adblocker/pull/5692) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.17.1 (Thu May 14 2026)

#### :nut_and_bolt: Dependencies

- Build(deps): Bump the production-dependencies group with 2 updates [#5678](https://github.com/ghostery/adblocker/pull/5678) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v2.17.0 (Fri May 08 2026)

#### :nut_and_bolt: Dependencies

- Update dependencies [#5665](https://github.com/ghostery/adblocker/pull/5665) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.6.0 to 25.6.2 [#5660](https://github.com/ghostery/adblocker/pull/5660) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.16.0 (Fri May 08 2026)

#### :house: Internal

- ci: migrate to node26 and update dependencies [#5654](https://github.com/ghostery/adblocker/pull/5654) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.14.2 (Mon Apr 27 2026)

#### ⚠️ Pushed to `master`

- Update dependencies ([@seia-soto](https://github.com/seia-soto))

#### :house: Internal

- internal: retire nodejs v20 [#5582](https://github.com/ghostery/adblocker/pull/5582) ([@seia-soto](https://github.com/seia-soto))
- internal: TypeScript 6.0 migration [#5546](https://github.com/ghostery/adblocker/pull/5546) ([@seia-soto](https://github.com/seia-soto))
- Housekeeping [#5518](https://github.com/ghostery/adblocker/pull/5518) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- Update dependencies [#5619](https://github.com/ghostery/adblocker/pull/5619) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.5.2 to 25.6.0 [#5592](https://github.com/ghostery/adblocker/pull/5592) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump tshy from 3.3.2 to 4.0.0 [#5551](https://github.com/ghostery/adblocker/pull/5551) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.3.2 to 25.3.3 [#5497](https://github.com/ghostery/adblocker/pull/5497) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.3.0 to 25.3.2 [#5494](https://github.com/ghostery/adblocker/pull/5494) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Update dependencies [#5486](https://github.com/ghostery/adblocker/pull/5486) ([@seia-soto](https://github.com/seia-soto))
- Build(deps): Bump @types/node from 25.2.3 to 25.3.0 [#5474](https://github.com/ghostery/adblocker/pull/5474) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.14.0 (Thu Feb 12 2026)

#### :rocket: New Feature

- feat: pseudo directives with `:remove` [#5397](https://github.com/ghostery/adblocker/pull/5397) ([@seia-soto](https://github.com/seia-soto))

#### :nut_and_bolt: Dependencies

- chore: update dependencies [#5455](https://github.com/ghostery/adblocker/pull/5455) ([@seia-soto](https://github.com/seia-soto))
- Build(deps-dev): Bump eslint from 9.39.2 to 10.0.0 [#5448](https://github.com/ghostery/adblocker/pull/5448) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps): Bump @types/node from 25.1.0 to 25.2.1 [#5437](https://github.com/ghostery/adblocker/pull/5437) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Update dependencies [#5422](https://github.com/ghostery/adblocker/pull/5422) ([@seia-soto](https://github.com/seia-soto))
- Update dependencies [#5399](https://github.com/ghostery/adblocker/pull/5399) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.13.4 (Wed Jan 14 2026)

#### :bug: Bug Fix

- fix(puppeteer): avoid the use of `$$eval` [#5384](https://github.com/ghostery/adblocker/pull/5384) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.13.0 (Thu Dec 04 2025)

#### :nut_and_bolt: Dependencies

- chore(internal): update dependencies [#5323](https://github.com/ghostery/adblocker/pull/5323) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.12.1 (Fri Oct 03 2025)

#### :nail_care: Polish

- chore(internal): update dependencies and replace node 18 with 24 [#5220](https://github.com/ghostery/adblocker/pull/5220) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.11.5 (Thu Aug 21 2025)

#### :nut_and_bolt: Dependencies

- Update dependencies [#5120](https://github.com/ghostery/adblocker/pull/5120) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.9.4 (Mon Jul 07 2025)

#### :bug: Bug Fix

- Prevent extended selectors duplicates [#5012](https://github.com/ghostery/adblocker/pull/5012) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v2.8.0 (Mon Jun 23 2025)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 22.15.30 to 24.0.1 [#4939](https://github.com/ghostery/adblocker/pull/4939) ([@dependabot[bot]](https://github.com/dependabot[bot]) [@seia-soto](https://github.com/seia-soto))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v2.1.0 (Wed Nov 20 2024)

#### :bug: Bug Fix

- Remove "branch=master" ([@regseb](https://github.com/regseb))
- docs: Fix build badges ([@regseb](https://github.com/regseb))

#### :memo: Documentation

- docs: Fix build badges [#4413](https://github.com/ghostery/adblocker/pull/4413) ([@regseb](https://github.com/regseb))

#### Authors: 1

- Sébastien Règne ([@regseb](https://github.com/regseb))

---

# v2.0.0 (Thu Oct 17 2024)

#### :boom: Breaking Change

- Rename from @cliqz/adblocker to @ghostery/adblocker [#4366](https://github.com/ghostery/adblocker/pull/4366) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.31.1 (Thu Aug 01 2024)

#### :bug: Bug Fix

- fix(adblocker-electron): `An object could not be cloned` [#4157](https://github.com/ghostery/adblocker/pull/4157) ([@seia-soto](https://github.com/seia-soto))

#### Authors: 1

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))

---

# v1.31.0 (Thu Aug 01 2024)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 20.14.12 to 22.0.2 [#4166](https://github.com/ghostery/adblocker/pull/4166) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.29.0 (Wed Jul 17 2024)

#### :house: Internal

- Replace Cliqz references with Ghostery [#4095](https://github.com/ghostery/adblocker/pull/4095) ([@chrmod](https://github.com/chrmod))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump rimraf from 5.0.8 to 6.0.1 [#4078](https://github.com/ghostery/adblocker/pull/4078) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.28.1 (Mon Jul 15 2024)

#### :bug: Bug Fix

- Simplify build with tshy [#4079](https://github.com/ghostery/adblocker/pull/4079) ([@chrmod](https://github.com/chrmod) [@seia-soto](https://github.com/seia-soto))

#### Authors: 2

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.28.0 (Tue Jul 09 2024)

#### :rocket: New Feature

- Optimise DOM mutation handling in `DOMMonitor` [#4071](https://github.com/ghostery/adblocker/pull/4071) ([@seia-soto](https://github.com/seia-soto) [@chrmod](https://github.com/chrmod) [@philipp-classen](https://github.com/philipp-classen))

#### :nut_and_bolt: Dependencies

- Update typescript [#4053](https://github.com/ghostery/adblocker/pull/4053) ([@chrmod](https://github.com/chrmod))

#### Authors: 3

- HoJeong Go ([@seia-soto](https://github.com/seia-soto))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))
- Philipp Claßen ([@philipp-classen](https://github.com/philipp-classen))

---

# v1.27.8 (Thu Jun 06 2024)

#### :bug: Bug Fix

- Bump version to: v1.27.7 \[skip ci\] [#4005](https://github.com/ghostery/adblocker/pull/4005) ([@adblocker-bot](https://github.com/adblocker-bot))
- Update CHANGELOG.md \[skip ci\] ([@adblocker-bot](https://github.com/adblocker-bot))

#### :nail_care: Polish

- Rename cliqz-oss to ghostery [#3986](https://github.com/ghostery/adblocker/pull/3986) ([@chrmod](https://github.com/chrmod))

#### ⚠️ Pushed to `master`

- Build system: update rollup plugins ([@chrmod](https://github.com/chrmod))

#### :house: Internal

- ESLint update [#3977](https://github.com/ghostery/adblocker/pull/3977) ([@chrmod](https://github.com/chrmod))
- ESM modules [#3924](https://github.com/ghostery/adblocker/pull/3924) ([@chrmod](https://github.com/chrmod))

#### Authors: 2

- Adblocker Bot ([@adblocker-bot](https://github.com/adblocker-bot))
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.27.4 (Wed Jun 05 2024)

#### :nail_care: Polish

- Rename cliqz-oss to ghostery [#3986](https://github.com/ghostery/adblocker/pull/3986) ([@chrmod](https://github.com/chrmod))

#### ⚠️ Pushed to `master`

- Build system: update rollup plugins ([@chrmod](https://github.com/chrmod))

#### :house: Internal

- ESLint update [#3977](https://github.com/ghostery/adblocker/pull/3977) ([@chrmod](https://github.com/chrmod))
- ESM modules [#3924](https://github.com/ghostery/adblocker/pull/3924) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.27.3 (Tue May 07 2024)

#### :nail_care: Polish

- Scriptlets: on Firefox bypass CSP by injecting blobs [#3942](https://github.com/ghostery/adblocker/pull/3942) ([@chrmod](https://github.com/chrmod))

#### Authors: 1

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.26.8 (Mon Oct 09 2023)

#### :house: Internal

- Replace tslint with eslint [#3450](https://github.com/ghostery/adblocker/pull/3450) ([@chrmod](https://github.com/chrmod))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump rollup from 3.29.2 to 4.0.2 [#3497](https://github.com/ghostery/adblocker/pull/3497) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Krzysztof Modras ([@chrmod](https://github.com/chrmod))

---

# v1.26.7 (Mon Sep 18 2023)

#### :bug: Bug Fix

- Attempt to fix publishing workflow [#3443](https://github.com/ghostery/adblocker/pull/3443) ([@remusao](https://github.com/remusao) [@chrmod](https://github.com/chrmod))
- Fix electron blocker performance regression [#3441](https://github.com/ghostery/adblocker/pull/3441) ([@remusao](https://github.com/remusao))

#### :house: Internal

- Updates of dependencies and CI [#3353](https://github.com/ghostery/adblocker/pull/3353) ([@remusao](https://github.com/remusao))

#### Authors: 2

- Krzysztof Modras ([@chrmod](https://github.com/chrmod))
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.26.6 (Fri Jun 02 2023)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump typescript from 4.9.5 to 5.0.4 [#3180](https://github.com/ghostery/adblocker/pull/3180) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.26.0 (Wed Feb 22 2023)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @rollup/plugin-typescript from 10.0.1 to 11.0.0 [#3003](https://github.com/ghostery/adblocker/pull/3003) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump rimraf from 3.0.2 to 4.0.7 [#3018](https://github.com/ghostery/adblocker/pull/3018) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.25.2 (Mon Jan 16 2023)

#### :house: Internal

- Update deps and CI [#2889](https://github.com/ghostery/adblocker/pull/2889) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @rollup/plugin-typescript from 9.0.2 to 10.0.1 [#2952](https://github.com/ghostery/adblocker/pull/2952) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Build(deps-dev): Bump @rollup/plugin-node-resolve from 14.1.0 to 15.0.0 [#2864](https://github.com/ghostery/adblocker/pull/2864) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.25.1 (Sat Sep 17 2022)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @rollup/plugin-node-resolve from 13.3.0 to 14.1.0 [#2817](https://github.com/ghostery/adblocker/pull/2817) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.23.9 (Fri Aug 19 2022)

#### :nut_and_bolt: Dependencies

- Build(deps-dev): Bump @types/node from 17.0.41 to 18.0.0 [#2664](https://github.com/ghostery/adblocker/pull/2664) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.23.7 (Wed Mar 23 2022)

#### :nail_care: Polish

- cosmetics: make sure we do not hide body or html elements [#2496](https://github.com/ghostery/adblocker/pull/2496) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.23.4 (Mon Jan 17 2022)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 16.11.10 to 17.0.8 [#2350](https://github.com/ghostery/adblocker/pull/2350) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v1.22.7 (Wed Sep 22 2021)

#### :house: Internal

- Bump typescript [#2243](https://github.com/ghostery/adblocker/pull/2243) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 15.6.1 to 16.9.6 [#2235](https://github.com/ghostery/adblocker/pull/2235) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.21.0 (Sun May 30 2021)

#### :rocket: New Feature

- Bump Electron to v13.x and Puppeteer to v9.x [#1967](https://github.com/ghostery/adblocker/pull/1967) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-node-resolve from 11.2.1 to 13.0.0 [#1912](https://github.com/ghostery/adblocker/pull/1912) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.20.5 (Tue May 04 2021)

#### :bug: Bug Fix

- build(deps-dev): bump @types/node from 14.14.41 to 15.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump auto from 10.25.1 to 10.25.2 [#1892](https://github.com/ghostery/adblocker/pull/1892) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps): bump tldts-experimental from 5.7.29 to 5.7.30 [#1889](https://github.com/ghostery/adblocker/pull/1889) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps-dev): bump @types/node from 14.14.41 to 15.0.0 [#1888](https://github.com/ghostery/adblocker/pull/1888) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.20.3 (Sat Feb 27 2021)

#### :house: Internal

- Update copyright notices [#1715](https://github.com/ghostery/adblocker/pull/1715) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.20.2 (Thu Feb 18 2021)

#### :bug: Bug Fix

- Fix puppeteer regression when handling DOM mutations [#1688](https://github.com/ghostery/adblocker/pull/1688) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.20.0 (Thu Jan 21 2021)

### Release Notes

#### Initial support for extended CSS selectors (a.k.a. procedural filters) ([#1574](https://github.com/ghostery/adblocker/pull/1574))

Add initial support for extended CSS selectors (a.k.a. procedural filters) as well as the `:remove()` modifier for element hiding rules (note: the already supported `:style` modified now also works with extended CSS selectors). The following new pseudo-classes are implemented: `:has` (and its alias `:if`), `:has-text` (both string and RegExp literals), and `:not` (whenever its argument is also an extended selector, otherwise fallback to native implementation).

Caveats:
* Loading of extended css filters is disabled by default and needs to be toggled using the `loadExtendedSelectors` option while [initializing the blocker instance](https://github.com/ghostery/adblocker/blob/3361723138f40c3cb96b4c6e611f2b030f75d891/packages/adblocker-webextension-example/background.ts#L61).
* These news selectors are currently only supported by `WebExtensionBlocker` (support for Puppeteer, Electron and Playwright is not planned at this time but help from the community would be greatly appreciated).

Miscellaneous changes:
* Removal of unused `injectCSSRule` helper.
* Replace Closure compiler by Terser.

---

#### :rocket: New Feature

- Initial support for extended CSS selectors (a.k.a. procedural filters) [#1574](https://github.com/ghostery/adblocker/pull/1574) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.19.0 (Wed Dec 16 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @rollup/plugin-node-resolve from 10.0.0 to 11.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @rollup/plugin-node-resolve from 10.0.0 to 11.0.0 [#1478](https://github.com/ghostery/adblocker/pull/1478) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.18.7 (Tue Nov 24 2020)

#### :nail_care: Polish

- Fix with newer Typescript + cleanups [#1466](https://github.com/ghostery/adblocker/pull/1466) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.18.4 (Sun Nov 01 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @rollup/plugin-node-resolve from 9.0.0 to 10.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @rollup/plugin-node-resolve from 9.0.0 to 10.0.0 [#1373](https://github.com/ghostery/adblocker/pull/1373) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.18.0 (Mon Aug 24 2020)

#### :bug: Bug Fix

- build(deps-dev): bump typescript from 3.9.7 to 4.0.2 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps-dev): bump @rollup/plugin-node-resolve from 8.4.0 to 9.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump typescript from 3.9.7 to 4.0.2 [#1202](https://github.com/ghostery/adblocker/pull/1202) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- build(deps-dev): bump @rollup/plugin-node-resolve from 8.4.0 to 9.0.0 [#1181](https://github.com/ghostery/adblocker/pull/1181) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- Update deps [#1107](https://github.com/ghostery/adblocker/pull/1107) ([@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v1.17.0 (Sun Jul 12 2020)

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @types/jsdom from 12.2.4 to 16.2.3 [#885](https://github.com/ghostery/adblocker/pull/885) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.16.0 (Wed Jun 10 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @ampproject/rollup-plugin-closure-compiler ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @ampproject/rollup-plugin-closure-compiler from 0.25.2 to 0.26.0 [#956](https://github.com/ghostery/adblocker/pull/956) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.15.0 (Sat May 23 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @rollup/plugin-node-resolve from 7.1.3 to 8.0.0 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @rollup/plugin-node-resolve from 7.1.3 to 8.0.0 [#907](https://github.com/ghostery/adblocker/pull/907) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.14.3 (Mon May 04 2020)

#### :bug: Bug Fix

- build(deps-dev): bump rollup-plugin-sourcemaps from 0.5.0 to 0.6.1 ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump rollup-plugin-sourcemaps from 0.5.0 to 0.6.1 [#830](https://github.com/ghostery/adblocker/pull/830) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.14.2 (Tue Apr 21 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @ampproject/rollup-plugin-closure-compiler ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- build(deps-dev): bump @ampproject/rollup-plugin-closure-compiler from 0.24.0 to 0.25.0 [#766](https://github.com/ghostery/adblocker/pull/766) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.14.1 (Thu Apr 09 2020)

### Release Notes

_From #746_

* Make sure that all unsupported procedural selectors from cosmetic filters are dropped to ensure that we only inject valid CSS selectors.
* Fix matching of `domain=` option for domain filters in cases where specified domain is a subdomain instead of full hostname or full domain.
* Fix partyness detection for requests without a valid domain (but having a valid hostname). This fixes matching against localhost request (for instance).
* Fix engine updates stress test which allows to replay all day-to-day diffs since the beginning of times... (currently about a year) and make sure that all updates work and resulting engine is byte-identical with diff-update or full initialization.
* Fix script to analyze size of serialized engines for all presets as well as all kinds of compression (i.e. none, gzip and brotli). This allows to keep track of final size after small-strings compression was applied.

---

#### :nail_care: Polish

- Fix domain options with subdomains and more... [#746](https://github.com/ghostery/adblocker/pull/746) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.14.0 (Wed Apr 08 2020)

### Release Notes

_From #738_

* Add `guessRequestTypeFromUrl` config option to all blocker classes which allows to automatically guess the type of network requests based on their URLs. This can be useful for cases where the type is either not available or not accurately inferred (e.g. when requests have time 'other').
* Fix a case where `PuppeteerBlocker` could show an async unhandled exception in console when trying to remove blocked iframes in pages.
* Fix redirection to binary resources (i.e. base64 encoded). An issue caused these resources to be corrupted which means that redirected resources were not valid (e.g. invalid PNG image).
* Redirection to local resources has been improved and will now always succeed thanks to a system of fallback. More types are also available for redirection.
* Improve API of blocker classes (i.e. PuppeteerBlocker, ElectronBlocker and WebExtensionBlocker) to allow creating custom blocking logic of resources using: `blockScripts`, `blockImages`, `blockMedias`, `blockFrames`, `blockFonts`, and `blockStyles`. These helpers can be called on any existing blocker instance, or on a new one created with the `empty()` static method.
* Add initial DSL (Domain Specific Language) to create blocking rules with a high-level API. This is used behind the scene to implement the new blocking methods now exposed by blocker instances. This new DSL should be considered alpha-quality and the API will likely change (and break) in the future. It might also be extended to handle hiding rules (a.k.a cosmetic filters).
* Fix behavior of `NetworkFilter#toString` which should now return a better pretty-printed version of the original filters whenever the `debug` option was false (in which case some information about the original raw string is lost and the string version needs to be inferred back).
* Implement handling of data: URLs. This means that the Request abstraction will now treat them as valid requests and that their type should always be inferred correctly. Moreover, the matching of data: URLs will now only take into account the prefix and ignore anything following the ',' separator.
* Requests with empty domain will not be treated as third-party anymore (this should not happen in the wild and was mostly impacting our unit tests).

---

#### :rocket: New Feature

- Various improvements [#738](https://github.com/ghostery/adblocker/pull/738) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.13.1 (Fri Apr 03 2020)

#### :memo: Documentation

- Fix line break in CHANGELOG.md [#691](https://github.com/ghostery/adblocker/pull/691) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.13.0 (Mon Mar 30 2020)

### Release Notes

_From #690_

PuppeteerBlocker is now more powerful and will be able to better block ads on most websites. Firstly, a bug was fixed which prevented injection of cosmetics in the main frame of pages. Secondly, PuppeteerBlocker will now monitor the DOM for changes to make sure that ads which load later are still "handled" (if you know what I mean). Lastly, PuppeteerBlocker is now able to look for advertisement iframes and remove them from the DOM completely, no more blank spaces left unattended...

---

#### :rocket: New Feature

- Fix PuppeteerBlocker and enable blocking of frames and DOM monitoring. [#690](https://github.com/ghostery/adblocker/pull/690) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.12.3 (Sat Mar 28 2020)

#### :house: Internal

- Update README.md [#670](https://github.com/ghostery/adblocker/pull/670) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.10.1 (Wed Mar 25 2020)

#### :bug: Bug Fix

- Abstract DOM monitoring away and fix #573 [#657](https://github.com/ghostery/adblocker/pull/657) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v1.10.0 (Wed Mar 25 2020)

#### :nut_and_bolt: Dependencies

-  [#587](https://github.com/ghostery/adblocker/pull/587) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
-  [#586](https://github.com/ghostery/adblocker/pull/586) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
-  [#560](https://github.com/ghostery/adblocker/pull/560) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.9.0 (Thu Feb 20 2020)

#### :bug: Bug Fix

- build(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.21.0 to 0.22.2.
- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.21.0...v0.22.2)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com>  ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v1.8.4 (Thu Feb 13 2020)

#### :bug: Bug Fix

- Fix implicit tslib dependency [#494](https://github.com/ghostery/adblocker/pull/494) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))
