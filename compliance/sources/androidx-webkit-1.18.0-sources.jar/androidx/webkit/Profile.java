/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.webkit;

import android.os.CancellationSignal;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.ServiceWorkerController;
import android.webkit.WebStorage;

import androidx.annotation.AnyThread;
import androidx.annotation.IntRange;
import androidx.annotation.RequiresFeature;
import androidx.annotation.RequiresOptIn;
import androidx.annotation.RestrictTo;
import androidx.annotation.UiThread;

import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;

/**
 * A Profile represents one browsing session for WebView.
 * <p> You can have multiple profiles and each profile holds its own set of data. The creation
 * and deletion of the Profile is being managed by {@link ProfileStore}.
 */
public interface Profile {

    /**
     * Represents the name of the default profile which can't be deleted.
     */
    String DEFAULT_PROFILE_NAME = "Default";

    /**
     * Returns the name of this Profile.
     *
     * @return the name of this Profile which was used to create the Profile from
     * ProfileStore create methods.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#MULTI_PROFILE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.MULTI_PROFILE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    String getName();

    /**
     * Returns the profile's cookie manager.
     * <p>
     * Can be called from any thread.
     *
     * @throws IllegalStateException         if the profile has been deleted by
     *                                       {@link ProfileStore#deleteProfile(String)}}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#MULTI_PROFILE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.MULTI_PROFILE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    CookieManager getCookieManager();

    /**
     * Returns the profile's web storage.
     * <p>
     * Can be called from any thread.
     *
     * @throws IllegalStateException         if the profile has been deleted by
     *                                       {@link ProfileStore#deleteProfile(String)}}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#MULTI_PROFILE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.MULTI_PROFILE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    WebStorage getWebStorage();

    /**
     *
     * Returns the {@link PrefetchCache} associated with this {@link Profile}.
     * Can be called from any thread.
     *
     * @throws IllegalStateException         if the profile has been deleted by
     *                                       {@link ProfileStore#deleteProfile(String)}}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PREFETCH_CACHE_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.PREFETCH_CACHE_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    @ExperimentalUrlPrefetch
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    default PrefetchCache getPrefetchCache() {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#getPrefetchCache is not implemented.");
    }

    /**
     * Returns the geolocation permissions of the profile.
     * <p>
     * Can be called from any thread.
     *
     * @throws IllegalStateException         if the profile has been deleted by
     *                                       {@link ProfileStore#deleteProfile(String)}}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#MULTI_PROFILE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.MULTI_PROFILE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    GeolocationPermissions getGeolocationPermissions();

    /**
     * Returns the service worker controller of the profile.
     * <p>
     * Can be called from any thread.
     *
     * @throws IllegalStateException         if the profile has been deleted by
     *                                       {@link ProfileStore#deleteProfile(String)}}.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#MULTI_PROFILE} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @AnyThread
    @RequiresFeature(name = WebViewFeature.MULTI_PROFILE,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    ServiceWorkerController getServiceWorkerController();

    /**
     * Denotes that the UrlPrefetch API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    @interface ExperimentalUrlPrefetch {
    }

    /**
     * Starts a URL prefetch request.
     * <p>
     * All WebViews associated with this Profile will use a URL request
     * matching algorithm during execution of all variants of
     * {@link android.webkit.WebView#loadUrl(String)} for determining if there
     * was already a prefetch request executed for the provided URL. This
     * includes prefetches that are "in progress". If a prefetch is matched,
     * WebView will leverage that for handling the URL, otherwise the URL
     * will be handled normally (i.e. through a network request).
     * <p>
     * Applications will still be responsible for calling
     * {@link android.webkit.WebView#loadUrl(String)} to display web contents
     * in a WebView.
     * <p>
     * NOTE: Additional headers passed to
     * {@link android.webkit.WebView#loadUrl(String, Map)} are not considered
     * in the matching algorithm for determining whether or not to serve a
     * prefetched response to a navigation.
     * <p>
     * For max latency saving benefits, it is recommended to call this method
     * as early as possible (i.e. before any WebView associated with this
     * profile is created).
     * <p>
     * Only supports HTTPS scheme.
     *
     * @param url                the url associated with the prefetch request.
     * @param cancellationSignal will make the best effort to cancel an
     *                           in-flight prefetch request, However cancellation is not
     *                           guaranteed.
     * @param callbackExecutor   the executor to resolve the callback with. If {@code null},
     *                           the callback will be executed on the main thread.
     * @param outcomeReceiver    callbacks for reporting result back to application.
     * @throws IllegalArgumentException      if the url or callback is null.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PROFILE_URL_PREFETCH} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated Use
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, WebViewOutcomeReceiver)} instead.
     */
    @RequiresFeature(name = WebViewFeature.PROFILE_URL_PREFETCH,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @AnyThread
    @ExperimentalUrlPrefetch
    @Deprecated
    void prefetchUrlAsync(
            @NonNull String url,
            @Nullable CancellationSignal cancellationSignal,
            @Nullable Executor callbackExecutor,
            @NonNull WebViewOutcomeReceiver<@Nullable Void, PrefetchException> outcomeReceiver);

    /**
     * Starts a URL prefetch request.
     * <p>
     * All WebViews associated with this Profile will use a URL request
     * matching algorithm during execution of all variants of
     * {@link android.webkit.WebView#loadUrl(String)} for determining if there
     * was already a prefetch request executed for the provided URL. This
     * includes prefetches that are "in progress". If a prefetch is matched,
     * WebView will leverage that for handling the URL, otherwise the URL
     * will be handled normally (i.e. through a network request).
     * <p>
     * Applications will still be responsible for calling
     * {@link android.webkit.WebView#loadUrl(String)} to display web contents
     * in a WebView.
     * <p>
     * NOTE: Additional headers passed to
     * {@link android.webkit.WebView#loadUrl(String, Map)} are not considered
     * in the matching algorithm for determining whether or not to serve a
     * prefetched response to a navigation.
     * <p>
     * For max latency saving benefits, it is recommended to call this method
     * as early as possible (i.e. before any WebView associated with this
     * profile is created).
     * <p>
     * Only supports HTTPS scheme.
     *
     * @param url                          the url associated with the prefetch request.
     * @param cancellationSignal           will make the best effort to cancel an
     *                                     in-flight prefetch request, However cancellation is not
     *                                     guaranteed.
     * @param callbackExecutor             the executor to resolve the callback with. If
     *                                     {@code null}, the callback will be executed on the
     *                                     main thread.
     * @param speculativeLoadingParameters parameters to customize the prefetch request.
     * @param outcomeReceiver              callbacks for reporting result back to application.
     * @throws IllegalArgumentException      if the url or callback is null.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PROFILE_URL_PREFETCH} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated Use
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, PrefetchParameters, WebViewOutcomeReceiver)} instead.
     */
    @RequiresFeature(name = WebViewFeature.PROFILE_URL_PREFETCH,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @AnyThread
    @ExperimentalUrlPrefetch
    @Deprecated
    void prefetchUrlAsync(
            @NonNull String url,
            @Nullable CancellationSignal cancellationSignal,
            @Nullable Executor callbackExecutor,
            @NonNull SpeculativeLoadingParameters speculativeLoadingParameters,
            @NonNull WebViewOutcomeReceiver<@Nullable Void, PrefetchException> outcomeReceiver);


    /**
     * Sets the {@link SpeculativeLoadingConfig} for the current profile session.
     * These configurations will be applied to any Prefetch requests made after they are set;
     * they will not be applied to in-flight requests.
     * <p>
     * These configurations will be applied to any prefetch requests initiated by
     * a prerender request. This applies specifically to WebViews that are
     * associated with this Profile.
     *
     * @param speculativeLoadingConfig the config to set for this profile session.
     * @deprecated use {@link Profile#setMaxPrerenders(int)},
     * {@link PrefetchCache#setMaxPrefetches(int)} and
     * {@link PrefetchCache#setPrefetchTtlSeconds(int)} instead.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SPECULATIVE_LOADING_CONFIG} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SPECULATIVE_LOADING_CONFIG,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalUrlPrefetch
    @Deprecated(forRemoval = true)
    void setSpeculativeLoadingConfig(@NonNull SpeculativeLoadingConfig
            speculativeLoadingConfig);

    /**
     * Sets the max prerenders for the current profile session.
     * These configurations will be applied to any prerender requests made after they are set;
     * they will not be applied to in-flight requests.
     * <p>
     * These configurations will be applied to WebViews that are associated with this Profile.
     *
     * @param maxPrerenders the prerender value to update.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SET_MAX_PRERENDERS_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SET_MAX_PRERENDERS_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalUrlPrefetch
    default void setMaxPrerenders(@IntRange(from = 1) int maxPrerenders) {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#setMaxPrerenders is not implemented.");
    }

    /**
     * Returns maximum prerenders for the current profile session.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SET_MAX_PRERENDERS_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SET_MAX_PRERENDERS_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalUrlPrefetch
    default int getMaxPrerenders() {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#getMaxPrerenders is not implemented.");
    }

    /**
     * Resets the max prerenders for the current profile session to system default.
     * This configuration will be applied to any prerender requests made after they are set;
     * they will not be applied to in-flight requests.
     * <p>
     * This configuration will be applied to WebViews that are associated with this Profile.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#SET_MAX_PRERENDERS_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.SET_MAX_PRERENDERS_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalUrlPrefetch
    default void clearMaxPrerenders() {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#clearMaxPrerenders is not implemented.");
    }

    /**
     * Denotes that the WarmUpRendererProcess API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    @interface ExperimentalWarmUpRendererProcess {
    }

    /**
     * Initiates warm-up of the renderer process associated with this Profile.
     * <p>
     * If no renderer currently exists for the profile, this will kick off the process of
     * starting one in the background. This call does not block or guarantee that the
     * renderer will be fully started by the time it returns.
     * <p>
     * This can be used to reduce perceived latency when a renderer is needed shortly after.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#WARM_UP_RENDERER_PROCESS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.WARM_UP_RENDERER_PROCESS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalWarmUpRendererProcess
    void warmUpRendererProcess();

    /**
     * Add a header for outgoing requests that match the given origin rules.
     * <p>
     * Changes to custom headers take effect on document load. For document-initiated requests
     * (such as subresources, {@code fetch()}, and {@code XMLHttpRequest}), the header will only
     * apply to documents that begin loading after this method is called; it does not affect
     * requests initiated by documents that are already loaded. Similarly, for requests sent from
     * service workers, the header will only apply to service workers that are started after this
     * method is called; it does not affect requests sent from service workers that are already
     * running. The header also applies to navigation requests to load new documents and prefetch
     * requests. It does not apply to WebSocket requests.
     * <p>
     * Headers added through this API will be present in the set returned by
     * getRequestHeaders provided in shouldInterceptRequest.
     * <p>
     * If this method is called multiple times with headers that have the same name and value,
     * then the sets of origin rules will be merged into a single set.
     * <p>
     * If multiple headers with the same name but different values match a request,
     * then all the values will be sent in a comma-separated list of values
     * following the guidance for <a
     * href="https://www.rfc-editor.org/rfc/rfc7230#section-3.2.2">repeated
     * header fields</a>. This does not take into account whether such merging is safe.
     *
     * <p>Headers are considered the same if their {@code name} matches case-insensitive and
     * their {@code value} matches case-sensitive.
     * This follows
     * <a href="https://www.rfc-editor.org/rfc/rfc9110.html#name-field-names">RFC 9110</a>,
     * which states that "field names are case insensitive".
     * This API will use the casing of the first custom header encountered.
     *
     * @param header The header to add.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default void addCustomHeader(@NonNull CustomHeader header) {
        // default to avoid breaking backwards compatibility.
    }

    /**
     * Returns true if the profile has a value set for the given header name.
     *
     * <p>This method is case insensitive.
     *
     * @param headerName A
     *                   <a href="https://datatracker.ietf.org/doc/html/rfc7230#section-3.2">valid HTTP header name string</a>
     * @return {@code true} if there is a value mapped for the provided {@code
     * headerName}, {code false} otherwise.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @see #addCustomHeader(CustomHeader)
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default boolean hasCustomHeader(@NonNull String headerName) {
        // default to avoid breaking backwards compatibility.
        return false;
    }

    /**
     * Returns all custom headers set with {@link #addCustomHeader(CustomHeader)}.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    @UiThread
    default Set<CustomHeader> getCustomHeaders() {
        // default to avoid breaking backwards compatibility.
        return Collections.emptySet();
    }

    /**
     * Returns all custom headers set with {@link #addCustomHeader(CustomHeader)} which have the
     * specified {@code name}.
     *
     * <p>This method is case insensitive.
     *
     * @param name Name of headers to get. Case sensitive.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    @UiThread
    default Set<CustomHeader> getCustomHeaders(@NonNull String name) {
        // default to avoid breaking backwards compatibility.
        return Collections.emptySet();
    }

    /**
     * Returns all custom headers set with {@link #addCustomHeader(CustomHeader)} which have the
     * specified {@code name} and {@code value}.
     *
     * <p>This method is case insensitive for {@code name} but case-sensitive for {@code value}.
     *
     * @param name  Name of headers to get. Case sensitive.
     * @param value Value of headers to get. Case sensitive.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @NonNull
    @UiThread
    default Set<CustomHeader> getCustomHeaders(@NonNull String name, @NonNull String value) {
        // default to avoid breaking backwards compatibility.
        return Collections.emptySet();
    }

    /**
     * Removes the specified headers from the set of headers attached to requests. This will
     * remove all configured headers that match {@code headerName}.
     * <p>
     * Changes to custom headers take effect on document load. For document-initiated requests,
     * the header will only be removed for documents that begin loading after this method is called;
     * requests initiated by documents that are already loaded will continue to send previously
     * configured headers.
     * <p>
     * It is safe to call this method even if {@code headerName} has not previously been set via
     * {@link #addCustomHeader(CustomHeader)}.
     *
     * <p>This method is case insensitive.
     *
     * @param headerName Header to remove.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @see #addCustomHeader(CustomHeader)
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default void clearCustomHeader(@NonNull String headerName) {
        // default to avoid breaking backwards compatibility.
    }

    /**
     * Removes the specified header from the set of headers attached to requests.
     * <p>
     * Changes to custom headers take effect on document load. For document-initiated requests,
     * the header will only be removed for documents that begin loading after this method is called;
     * requests initiated by documents that are already loaded will continue to send previously
     * configured headers.
     * <p>
     * It is safe to call this method even if {@code (headerName, headerValue)} has not
     * previously been set via {@link #addCustomHeader(CustomHeader)}.
     *
     * <p>This method is case insensitive for {@code name} but case-sensitive for {@code value}.
     *
     * @param headerName  Header name to remove.
     * @param headerValue Header value to remove.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @see #addCustomHeader(CustomHeader)
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default void clearCustomHeader(@NonNull String headerName, @NonNull String headerValue) {
        // default to avoid breaking backwards compatibility.
    }

    /**
     * Remove any currently set headers from being applied to network requests.
     * <p>
     * Changes to custom headers take effect on document load. For document-initiated requests,
     * headers will only be removed for documents that begin loading after this method is called;
     * requests initiated by documents that are already loaded will continue to send previously
     * configured headers.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CUSTOM_REQUEST_HEADERS} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @see #addCustomHeader(CustomHeader)
     */
    @RequiresFeature(name = WebViewFeature.CUSTOM_REQUEST_HEADERS,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default void clearAllCustomHeaders() {
        // default to avoid breaking backwards compatibility.
    }

    /**
     * Denotes that the Profile#preconnect API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    @interface ExperimentalPreconnect {
    }

    /**
     * Preconnect to the given origin to speed up future network requests.
     * <p>
     * Opens a connection to the provided origin, performing DNS lookup and TCP/TLS handshakes. This
     * can speed up future loads to the origin which could use the open connection. The connection
     * will remain open (and can be reused by future loads) until it times out (roughly 30s).
     * <p>
     * The main benefit of this API is to preconnect to origins that haven't yet been visited by a
     * WebView - it provides no further performance benefit to origins that have already been
     * loaded.
     * <p>
     * Note: Preconnect operates on origins, but for convenience full URLs can be provided. A call
     * with a full URL (such as {@code https://www.example.com/index.html}) will be treated as a
     * call
     * to the origin ({@code https://www.example.com}).
     * <p>
     * Multiple origins can be connected to by calling this API multiple times.
     * <p>
     * See:
     * <a href="https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/rel/preconnect">HTML Preconnect Specification</a>
     *
     * @param url A url containing the origin to open a connection to.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#PRECONNECT} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.PRECONNECT,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalPreconnect
    default void preconnect(@NonNull String url) {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#preconnect is not implemented.");
    }

    /**
     * Enqueue a network preconnect to occur once WebView has started up.
     * <p>
     * This method acts like {@link #preconnect(String)} but doesn't trigger WebView start up.
     * Instead, it enqueues that action for when WebView start up occurs.
     * If the WebView has already started, this method acts exactly like {@link #preconnect(String)}
     * <p>
     * @param url A url containing the origin to open a connection to.
     * @throws UnsupportedOperationException if the
     * {@link WebViewFeature#ENQUEUE_PRECONNECT} feature is not supported.
     * @see Profile#preconnect(String)
     */
    @RequiresFeature(name = WebViewFeature.ENQUEUE_PRECONNECT,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalPreconnect
    default void enqueuePreconnect(@NonNull String url) {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#enqueuePreconnect is not implemented.");
    }

    /**
     * Denotes that the Profile#addQuicHints API surface is experimental.
     * It may change without warning.
     */
    @Retention(RetentionPolicy.CLASS)
    @Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
    @RequiresOptIn(level = RequiresOptIn.Level.ERROR)
    @interface ExperimentalAddQuicHints {
    }

    /**
     * Advises that the given origins support the QUIC protocol and that WebView should use that to
     * connect to them.
     * <p>
     * By default, when connecting to a new server, WebView attempts both a HTTP3 (QUIC) and HTTP2
     * connection, choosing the one that responds faster. This can lead to cases where HTTP2
     * responds faster, even though HTTP3 is supported and would result in a faster overall load.
     * Calling this API tells WebView to prefer HTTP3 connections for these origins.
     * <p>
     * Note: addQuicHints operates on origins, but for convenience full URLs can be provided. A full
     * URL (such as {@code https://www.example.com/index.html}) will be treated as its origin
     * ({@code https://www.example.com}).
     * <p>
     * This method can be called multiple times and the result is additive - QUIC hints are applied
     * to all of the origins provided to all calls. Providing the same origin multiple times has no
     * further effect.
     *
     * @param urls A set of urls representing origins that support the QUIC protocol.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ADD_QUIC_HINTS_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     * @deprecated This method is being renamed to {@link #preferQuicFor(Set)}, use that instead.
     *     There is no difference in functionality.
     */
    @RequiresFeature(name = WebViewFeature.ADD_QUIC_HINTS_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalAddQuicHints
    @Deprecated(forRemoval = true)
    default void addQuicHints(@NonNull Set<@NonNull String> urls) {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#addQuicHints is not implemented.");
    }

    /**
     * Advises that the given origins support the QUIC protocol and that WebView should use that to
     * connect to them.
     * <p>
     * By default, when connecting to a new server, WebView attempts both a HTTP3 (QUIC) and HTTP2
     * connection, choosing the one that responds faster. This can lead to cases where HTTP2
     * responds faster, even though HTTP3 is supported and would result in a faster overall load.
     * Calling this API tells WebView to prefer HTTP3 connections for these origins.
     * <p>
     * Note: preferQuicFor operates on origins, but for convenience full URLs can be provided. A
     * full URL (such as {@code https://www.example.com/index.html}) will be treated as its origin
     * ({@code https://www.example.com}).
     * <p>
     * This method can be called multiple times and the result is additive - QUIC hints are applied
     * to all of the origins provided to all calls. Providing the same origin multiple times has no
     * further effect.
     *
     * @param urls A set of urls representing origins that support the QUIC protocol.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#ADD_QUIC_HINTS_V1} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.ADD_QUIC_HINTS_V1,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    @ExperimentalAddQuicHints
    default void preferQuicFor(@NonNull Set<@NonNull String> urls) {
        // We provide a default implementation of this method so that embedders extending the
        // Profile (eg, for testing) don't have their build broken by the addition of this
        // method. However, throw a runtime exception if this method is actually called, as
        // that's better than silently no-oping.
        throw new UnsupportedOperationException("Profile#preferQuicFor is not implemented.");
    }

    /**
     * Returns the {@link HttpCache} associated with this {@link Profile}.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#HTTP_CACHE_MANAGER} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.HTTP_CACHE_MANAGER,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default @NonNull HttpCache getHttpCache() {
        throw new UnsupportedOperationException("Profile#getHttpCache is not implemented.");
    }

    /**
     * Get the current allowlist of origins, with explicitly written ports, for cross-origin
     * isolated APIs.
     * <p>
     * If setting the origin rule {@code https://example.com}, this method will return the same
     * origin rule as {@code https://example.com:443}).
     *
     * @return An empty set if no allowlist has been set.
     *
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CROSS_ORIGIN_ISOLATED_ALLOWLIST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CROSS_ORIGIN_ISOLATED_ALLOWLIST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default @NonNull Set<String> getCrossOriginIsolatedAllowlist() {
        throw new UnsupportedOperationException("Profile#getCrossOriginIsolatedAllowlist is "
                + "not implemented.");
    }

    /**
     * Set the list of origin patterns where <a href="https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Permissions-Policy/cross-origin-isolated">Cross Origin Isolated APIs</a> should be accessible.
     * <p>
     * This API allows you to set an allowlist of origins where potentially risky APIs will be
     * enabled, provided the loaded page has the correct <a href="https://developer.chrome.com/blog/document-isolation-policy">{@code Document-Isolation-Policy}</a>
     * response header.
     * <p>
     * WebView does not enable this feature by default because WebView does not support renderer
     * process isolation. By calling this API, you acknowledge that it is OK to relax this security
     * guarantee and allow pages to use cross-origin-isolated APIs, for example <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/SharedArrayBuffer">SharedArrayBuffer</a>
     * even if they are running in a shared renderer process. For this reason, you should only use
     * this API with origins you trust.
     * <p>
     * You should also avoid using the wildcard matcher ({@code "*"}) in the {@code originPatterns}
     * for the same reason.
     * <p>
     * This method will affect pages that are already loaded.
     *
     * @param allowedOriginRules A set of origin patterns where cross-origin-isolated APIs should be
     *                       available. Avoid using the wildcard matcher. See the documentation for
     *                       {@link WebViewCompat#addWebMessageListener} for syntax.
     * @throws IllegalArgumentException if one or more of the patterns cannot be parsed.
     * @throws UnsupportedOperationException if the
     *     {@link WebViewFeature#CROSS_ORIGIN_ISOLATED_ALLOWLIST} feature is not supported.
     *     This should be checked before use with {@link WebViewFeature#isFeatureSupported}.
     */
    @RequiresFeature(name = WebViewFeature.CROSS_ORIGIN_ISOLATED_ALLOWLIST,
            enforcement = "androidx.webkit.WebViewFeature#isFeatureSupported")
    @UiThread
    default void setCrossOriginIsolatedAllowlist(@NonNull Set<String> allowedOriginRules) {
        throw new UnsupportedOperationException("Profile#setCrossOriginIsolatedAllowlist is "
                + "not implemented.");
    }

}
