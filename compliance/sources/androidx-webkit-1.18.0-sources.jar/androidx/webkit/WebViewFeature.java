/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.webkit;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;

import androidx.annotation.RestrictTo;
import androidx.annotation.StringDef;
import androidx.webkit.internal.WebViewFeatureInternal;

import org.jspecify.annotations.NonNull;

import java.io.File;
import java.io.OutputStream;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executor;

/**
 * Utility class for checking which WebView Support Library features are supported on the device.
 */
public class WebViewFeature {

    private WebViewFeature() {
    }

    /**
     *
     */
    @SuppressLint("UnsafeOptInUsageError") // Don't mark WebViewSupportFeature as experimental.
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    @StringDef(value = {
            VISUAL_STATE_CALLBACK,
            OFF_SCREEN_PRERASTER,
            SAFE_BROWSING_ENABLE,
            DISABLED_ACTION_MODE_MENU_ITEMS,
            START_SAFE_BROWSING,
            SAFE_BROWSING_ALLOWLIST,
            SAFE_BROWSING_WHITELIST,
            SAFE_BROWSING_PRIVACY_POLICY_URL,
            SERVICE_WORKER_BASIC_USAGE,
            SERVICE_WORKER_CACHE_MODE,
            SERVICE_WORKER_CONTENT_ACCESS,
            SERVICE_WORKER_FILE_ACCESS,
            SERVICE_WORKER_BLOCK_NETWORK_LOADS,
            SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST,
            RECEIVE_WEB_RESOURCE_ERROR,
            RECEIVE_HTTP_ERROR,
            SHOULD_OVERRIDE_WITH_REDIRECTS,
            SAFE_BROWSING_HIT,
            TRACING_CONTROLLER_BASIC_USAGE,
            WEB_RESOURCE_REQUEST_IS_REDIRECT,
            WEB_RESOURCE_ERROR_GET_DESCRIPTION,
            WEB_RESOURCE_ERROR_GET_CODE,
            SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY,
            SAFE_BROWSING_RESPONSE_PROCEED,
            SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL,
            WEB_MESSAGE_PORT_POST_MESSAGE,
            WEB_MESSAGE_PORT_CLOSE,
            WEB_MESSAGE_ARRAY_BUFFER,
            WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK,
            CREATE_WEB_MESSAGE_CHANNEL,
            POST_WEB_MESSAGE,
            WEB_MESSAGE_CALLBACK_ON_MESSAGE,
            GET_WEB_VIEW_CLIENT,
            GET_WEB_CHROME_CLIENT,
            GET_WEB_VIEW_RENDERER,
            WEB_VIEW_RENDERER_TERMINATE,
            WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE,
            PROXY_OVERRIDE,
            MULTI_PROCESS,
            FORCE_DARK,
            FORCE_DARK_STRATEGY,
            WEB_MESSAGE_LISTENER,
            DOCUMENT_START_SCRIPT,
            PROXY_OVERRIDE_REVERSE_BYPASS,
            GET_VARIATIONS_HEADER,
            ALGORITHMIC_DARKENING,
            ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY,
            GET_COOKIE_INFO,
            REQUESTED_WITH_HEADER_ALLOW_LIST,
            USER_AGENT_METADATA,
            USER_AGENT_METADATA_FORM_FACTORS,
            MULTI_PROFILE,
            ATTRIBUTION_REGISTRATION_BEHAVIOR,
            WEBVIEW_MEDIA_INTEGRITY_API_STATUS,
            MUTE_AUDIO,
            PROFILE_URL_PREFETCH,
            WEB_AUTHENTICATION,
            SPECULATIVE_LOADING,
            BACK_FORWARD_CACHE,
            DEFAULT_TRAFFICSTATS_TAGGING,
            DELETE_BROWSING_DATA,
            PRERENDER_WITH_URL,
            SAVE_STATE,
            NAVIGATION_GET_WEB_RESOURCE_ERROR,
            NAVIGATION_CALLBACK_BASIC,
            NAVIGATION_LISTENER_V1,
            NAVIGATION_LISTENER_V2,
            NAVIGATION_LISTENER_ON_COMPLETED_FIRES_FOR_NON_COMMITTED,
            PAYMENT_REQUEST,
            WEBVIEW_BUILDER_EXPERIMENTAL_V1,
            WEBVIEW_BUILDER_EXPERIMENTAL_V2,
            WARM_UP_RENDERER_PROCESS,
            PRECONNECT,
            PROVIDER_WEAKLY_REF_WEBVIEW,
            HYPERLINK_CONTEXT_MENU_ITEMS,
            CUSTOM_REQUEST_HEADERS,
            ADD_QUIC_HINTS_V1,
            PAGE_GET_URL,
            PREFETCH_CACHE_V1,
            SET_MAX_PRERENDERS_V1,
            JS_INJECTION_IN_FRAME_AND_WORLD,
            NAVIGATION_LISTENER,
            WEBVIEW_NAVIGATE_EXPERIMENTAL_V1,
            DOWNLOAD_FAVICONS_ENABLED,
            HTTP_CACHE_MANAGER,
            CROSS_ORIGIN_ISOLATED_ALLOWLIST,
    })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.PARAMETER, ElementType.METHOD})
    public @interface WebViewSupportFeature {
    }

    /**
     *
     */
    @SuppressLint("UnsafeOptInUsageError") // Don't mark WebViewStartupFeature as experimental.
    @RestrictTo(RestrictTo.Scope.LIBRARY)
    @StringDef(value = {
            STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX,
            STARTUP_FEATURE_SET_DIRECTORY_BASE_PATHS,
            STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES,
            STARTUP_FEATURE_SET_PROFILES_TO_LOAD,
            STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2,
    })
    @Retention(RetentionPolicy.SOURCE)
    @Target({ElementType.PARAMETER, ElementType.METHOD})
    public @interface WebViewStartupFeature {
    }

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#postVisualStateCallback(WebView, long,
     * WebViewCompat.VisualStateCallback)}, and {@link
     * WebViewClientCompat#onPageCommitVisible(WebView, String)}.
     */
    public static final String VISUAL_STATE_CALLBACK = "VISUAL_STATE_CALLBACK";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getOffscreenPreRaster(WebSettings)}, and
     * {@link WebSettingsCompat#setOffscreenPreRaster(WebSettings, boolean)}.
     */
    public static final String OFF_SCREEN_PRERASTER = "OFF_SCREEN_PRERASTER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getSafeBrowsingEnabled(WebSettings)}, and
     * {@link WebSettingsCompat#setSafeBrowsingEnabled(WebSettings, boolean)}.
     */
    public static final String SAFE_BROWSING_ENABLE = "SAFE_BROWSING_ENABLE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getDisabledActionModeMenuItems(WebSettings)}, and
     * {@link WebSettingsCompat#setDisabledActionModeMenuItems(WebSettings, int)}.
     */
    @SuppressLint("IntentName") // False positive: this constant is not to be used for Intents.
    public static final String DISABLED_ACTION_MODE_MENU_ITEMS =
            "DISABLED_ACTION_MODE_MENU_ITEMS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#startSafeBrowsing(Context, ValueCallback)}.
     */
    public static final String START_SAFE_BROWSING = "START_SAFE_BROWSING";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#setSafeBrowsingAllowlist(Set, ValueCallback)}.
     */
    public static final String SAFE_BROWSING_ALLOWLIST = "SAFE_BROWSING_ALLOWLIST";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#setSafeBrowsingWhitelist(List, ValueCallback)}.
     *
     * <p>This is functionally equivalent to {@link #SAFE_BROWSING_ALLOWLIST}: both constants
     * represent the same range of compatibility across Android OS versions and WebView versions.
     *
     * @deprecated Please use {@link #SAFE_BROWSING_ALLOWLIST} and {@link
     * WebViewCompat#setSafeBrowsingAllowlist(Set, ValueCallback)} instead.
     */
    @Deprecated
    public static final String SAFE_BROWSING_WHITELIST = "SAFE_BROWSING_WHITELIST";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#getSafeBrowsingPrivacyPolicyUrl()}.
     */
    public static final String SAFE_BROWSING_PRIVACY_POLICY_URL =
            "SAFE_BROWSING_PRIVACY_POLICY_URL";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerControllerCompat#getInstance()}.
     */
    public static final String SERVICE_WORKER_BASIC_USAGE = "SERVICE_WORKER_BASIC_USAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getCacheMode()}, and
     * {@link ServiceWorkerWebSettingsCompat#setCacheMode(int)}.
     */
    public static final String SERVICE_WORKER_CACHE_MODE = "SERVICE_WORKER_CACHE_MODE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getAllowContentAccess()}, and
     * {@link ServiceWorkerWebSettingsCompat#setAllowContentAccess(boolean)}.
     */
    public static final String SERVICE_WORKER_CONTENT_ACCESS =
            "SERVICE_WORKER_CONTENT_ACCESS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getAllowFileAccess()}, and
     * {@link ServiceWorkerWebSettingsCompat#setAllowFileAccess(boolean)}.
     */
    public static final String SERVICE_WORKER_FILE_ACCESS = "SERVICE_WORKER_FILE_ACCESS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerWebSettingsCompat#getBlockNetworkLoads()}, and
     * {@link ServiceWorkerWebSettingsCompat#setBlockNetworkLoads(boolean)}.
     */
    public static final String SERVICE_WORKER_BLOCK_NETWORK_LOADS =
            "SERVICE_WORKER_BLOCK_NETWORK_LOADS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ServiceWorkerClientCompat#shouldInterceptRequest(WebResourceRequest)}.
     */
    public static final String SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST =
            "SERVICE_WORKER_SHOULD_INTERCEPT_REQUEST";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewClientCompat#onReceivedError(WebView, WebResourceRequest,
     * WebResourceErrorCompat)}.
     */
    public static final String RECEIVE_WEB_RESOURCE_ERROR = "RECEIVE_WEB_RESOURCE_ERROR";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewClientCompat#onReceivedHttpError(WebView, WebResourceRequest,
     * WebResourceResponse)}.
     */
    public static final String RECEIVE_HTTP_ERROR = "RECEIVE_HTTP_ERROR";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewClientCompat#shouldOverrideUrlLoading(WebView, WebResourceRequest)}.
     */
    public static final String SHOULD_OVERRIDE_WITH_REDIRECTS =
            "SHOULD_OVERRIDE_WITH_REDIRECTS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewClientCompat#onSafeBrowsingHit(WebView,
     * WebResourceRequest, int, SafeBrowsingResponseCompat)}.
     */
    public static final String SAFE_BROWSING_HIT = "SAFE_BROWSING_HIT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link TracingController#getInstance()},
     * {@link TracingController#isTracing()},
     * {@link TracingController#start(TracingConfig)},
     * {@link TracingController#stop(OutputStream, Executor)}.
     */
    public static final String TRACING_CONTROLLER_BASIC_USAGE =
            "TRACING_CONTROLLER_BASIC_USAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebResourceRequestCompat#isRedirect(WebResourceRequest)}.
     */
    public static final String WEB_RESOURCE_REQUEST_IS_REDIRECT =
            "WEB_RESOURCE_REQUEST_IS_REDIRECT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebResourceErrorCompat#getDescription()}.
     */
    public static final String WEB_RESOURCE_ERROR_GET_DESCRIPTION =
            "WEB_RESOURCE_ERROR_GET_DESCRIPTION";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebResourceErrorCompat#getErrorCode()}.
     */
    public static final String WEB_RESOURCE_ERROR_GET_CODE =
            "WEB_RESOURCE_ERROR_GET_CODE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link SafeBrowsingResponseCompat#backToSafety(boolean)}.
     */
    public static final String SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY =
            "SAFE_BROWSING_RESPONSE_BACK_TO_SAFETY";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link SafeBrowsingResponseCompat#proceed(boolean)}.
     */
    public static final String SAFE_BROWSING_RESPONSE_PROCEED =
            "SAFE_BROWSING_RESPONSE_PROCEED";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link SafeBrowsingResponseCompat#showInterstitial(boolean)}.
     */
    public static final String SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL =
            "SAFE_BROWSING_RESPONSE_SHOW_INTERSTITIAL";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebMessagePortCompat#postMessage(WebMessageCompat)}.
     */
    public static final String WEB_MESSAGE_PORT_POST_MESSAGE =
            "WEB_MESSAGE_PORT_POST_MESSAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebMessagePortCompat#close()}.
     */
    public static final String WEB_MESSAGE_PORT_CLOSE = "WEB_MESSAGE_PORT_CLOSE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebMessagePortCompat#postMessage(WebMessageCompat)} with ArrayBuffer type,
     * {@link WebViewCompat#postWebMessage(WebView, WebMessageCompat, Uri)} with ArrayBuffer type,
     * and {@link JavaScriptReplyProxy#postMessage(byte[])}.
     */
    public static final String WEB_MESSAGE_ARRAY_BUFFER = "WEB_MESSAGE_ARRAY_BUFFER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebMessagePortCompat#setWebMessageCallback(
     * WebMessagePortCompat.WebMessageCallbackCompat)}, and
     * {@link WebMessagePortCompat#setWebMessageCallback(Handler,
     * WebMessagePortCompat.WebMessageCallbackCompat)}.
     */
    public static final String WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK =
            "WEB_MESSAGE_PORT_SET_MESSAGE_CALLBACK";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#createWebMessageChannel(WebView)}.
     */
    public static final String CREATE_WEB_MESSAGE_CHANNEL = "CREATE_WEB_MESSAGE_CHANNEL";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#postWebMessage(WebView, WebMessageCompat, Uri)}.
     */
    public static final String POST_WEB_MESSAGE = "POST_WEB_MESSAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebMessagePortCompat.WebMessageCallbackCompat#onMessage(WebMessagePortCompat,
     * WebMessageCompat)}.
     */
    public static final String WEB_MESSAGE_CALLBACK_ON_MESSAGE =
            "WEB_MESSAGE_CALLBACK_ON_MESSAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#getWebViewClient(WebView)}
     */
    public static final String GET_WEB_VIEW_CLIENT = "GET_WEB_VIEW_CLIENT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#getWebChromeClient(WebView)}
     */
    public static final String GET_WEB_CHROME_CLIENT = "GET_WEB_CHROME_CLIENT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#getWebViewRenderProcess(WebView)}
     */
    public static final String GET_WEB_VIEW_RENDERER = "GET_WEB_VIEW_RENDERER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewRenderProcess#terminate()}
     */
    public static final String WEB_VIEW_RENDERER_TERMINATE = "WEB_VIEW_RENDERER_TERMINATE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#getWebViewRenderProcessClient(WebView)},
     * {@link WebViewCompat#setWebViewRenderProcessClient(WebView, WebViewRenderProcessClient)},
     */
    public static final String WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE =
            "WEB_VIEW_RENDERER_CLIENT_BASIC_USAGE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link ProxyController#setProxyOverride(ProxyConfig, Executor, Runnable)},
     * {@link ProxyController#clearProxyOverride(Executor, Runnable)}, and
     */
    public static final String PROXY_OVERRIDE = "PROXY_OVERRIDE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#isMultiProcessEnabled()}
     */
    public static final String MULTI_PROCESS = "MULTI_PROCESS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setForceDark(WebSettings, int)} and
     * {@link WebSettingsCompat#getForceDark(WebSettings)}.
     */
    public static final String FORCE_DARK = "FORCE_DARK";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setForceDarkStrategy(WebSettings, int)} and
     * {@link WebSettingsCompat#getForceDarkStrategy(WebSettings)}.
     */
    public static final String FORCE_DARK_STRATEGY = "FORCE_DARK_STRATEGY";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setAlgorithmicDarkeningAllowed(WebSettings, boolean)} and
     * {@link WebSettingsCompat#isAlgorithmicDarkeningAllowed(WebSettings)}.
     */
    public static final String ALGORITHMIC_DARKENING = "ALGORITHMIC_DARKENING";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#addWebMessageListener(WebView,
     * String, Set, WebViewCompat.WebMessageListener)} and {@link
     * WebViewCompat#removeWebMessageListener(WebView, String)}.
     */
    public static final String WEB_MESSAGE_LISTENER = "WEB_MESSAGE_LISTENER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#addDocumentStartJavaScript(WebView, String, Set)}.
     */
    public static final String DOCUMENT_START_SCRIPT = "DOCUMENT_START_SCRIPT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link ProxyConfig.Builder#setReverseBypassEnabled(boolean)}
     */
    public static final String PROXY_OVERRIDE_REVERSE_BYPASS = "PROXY_OVERRIDE_REVERSE_BYPASS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#getVariationsHeader()}.
     */
    public static final String GET_VARIATIONS_HEADER = "GET_VARIATIONS_HEADER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setEnterpriseAuthenticationAppLinkPolicyEnabled(WebSettings, boolean)}and
     * {@link WebSettingsCompat#getEnterpriseAuthenticationAppLinkPolicyEnabled(WebSettings)}.
     */
    public static final String ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY =
            "ENTERPRISE_AUTHENTICATION_APP_LINK_POLICY";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link CookieManagerCompat#getCookieInfo(CookieManager, String)}.
     */
    public static final String GET_COOKIE_INFO = "GET_COOKIE_INFO";

    /**
     * Feature for {@link #isStartupFeatureSupported(Context, String)}.
     * This feature covers {@link ProcessGlobalConfig#setDataDirectorySuffix(Context, String)}.
     */
    public static final String STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX =
            "STARTUP_FEATURE_SET_DATA_DIRECTORY_SUFFIX";

    /**
     * Feature for {@link #isStartupFeatureSupported(Context, String)}.
     * This feature covers {@link ProcessGlobalConfig#setDirectoryBasePaths(Context, File, File)}
     */
    public static final String STARTUP_FEATURE_SET_DIRECTORY_BASE_PATHS =
            "STARTUP_FEATURE_SET_DIRECTORY_BASE_PATHS";

    /**
     * Feature for {@link #isStartupFeatureSupported(Context, String)}.
     * This feature covers
     * {@link ProcessGlobalConfig#setPartitionedCookiesEnabled(Context, boolean)}
     */
    public static final String STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES =
            "STARTUP_FEATURE_CONFIGURE_PARTITIONED_COOKIES";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getRequestedWithHeaderOriginAllowList(WebSettings)},
     * {@link WebSettingsCompat#setRequestedWithHeaderOriginAllowList(WebSettings, Set)},
     * {@link ServiceWorkerWebSettingsCompat#getRequestedWithHeaderOriginAllowList()},
     * {@link ServiceWorkerWebSettingsCompat#setRequestedWithHeaderOriginAllowList(Set)}
     *
     * @deprecated The origin trial to disable the X-Requested-With feature has ended, so this
     * API no longer does anything.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Deprecated
    public static final String REQUESTED_WITH_HEADER_ALLOW_LIST =
            "REQUESTED_WITH_HEADER_ALLOW_LIST";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#getUserAgentMetadata(WebSettings)}, and
     * {@link WebSettingsCompat#setUserAgentMetadata(WebSettings, UserAgentMetadata)}.
     */
    public static final String USER_AGENT_METADATA = "USER_AGENT_METADATA";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link UserAgentMetadata.Builder#setFormFactors(List)}, and
     * {@link UserAgentMetadata#getFormFactors()}.
     */
    public static final String USER_AGENT_METADATA_FORM_FACTORS =
            "USER_AGENT_METADATA_FORM_FACTORS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#getName()}.
     * {@link Profile#getWebStorage()}.
     * {@link Profile#getCookieManager()}.
     * {@link Profile#getGeolocationPermissions()}.
     * {@link Profile#getServiceWorkerController()}.
     * {@link ProfileStore#getProfile(String)}.
     * {@link ProfileStore#getOrCreateProfile(String)}.
     * {@link ProfileStore#getAllProfileNames()}.
     * {@link ProfileStore#deleteProfile(String)}.
     * {@link ProfileStore#getInstance()}.
     */
    public static final String MULTI_PROFILE = "MULTI_PROFILE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setAttributionRegistrationBehavior(WebSettings, int)}
     * {@link WebSettingsCompat#getAttributionRegistrationBehavior(WebSettings)}
     */
    public static final String ATTRIBUTION_REGISTRATION_BEHAVIOR =
            "ATTRIBUTION_REGISTRATION_BEHAVIOR";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setWebViewMediaIntegrityApiStatus(WebSettings, WebViewMediaIntegrityApiStatusConfig)}
     * {@link WebSettingsCompat#getWebViewMediaIntegrityApiStatus(WebSettings)}
     */
    public static final String WEBVIEW_MEDIA_INTEGRITY_API_STATUS =
            "WEBVIEW_MEDIA_INTEGRITY_API_STATUS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebViewCompat#isAudioMuted(WebView)}
     * {@link WebViewCompat#setAudioMuted(WebView, boolean)}
     */
    public static final String MUTE_AUDIO = "MUTE_AUDIO";

    /**
     * Feature for {@link #isFeatureSupported(String)}
     * This feature covers
     * {@link WebSettingsCompat#setWebAuthenticationSupport(WebSettings, int)}
     * {@link WebSettingsCompat#getWebAuthenticationSupport(WebSettings)}
     */
    public static final String WEB_AUTHENTICATION = "WEB_AUTHENTICATION";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setSpeculativeLoadingStatus(WebSettings, int)}
     * {@link WebSettingsCompat#getSpeculativeLoadingStatus(WebSettings)}}
     */
    public static final String SPECULATIVE_LOADING =
            "SPECULATIVE_LOADING_STATUS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setBackForwardCacheEnabled(WebSettings, boolean)}
     * {@link WebSettingsCompat#getBackForwardCacheEnabled(WebSettings)}
     */
    public static final String BACK_FORWARD_CACHE = "BACK_FORWARD_CACHE";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setBackForwardCacheEnabled(WebSettings, boolean)}
     * {@link WebSettingsCompat#getBackForwardCacheSettings(WebSettings)}
     */
    public static final String BACK_FORWARD_CACHE_SETTINGS = "BACK_FORWARD_CACHE_SETTINGS";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link BackForwardCacheSettings#setMaxPagesInCache(int)}
     * {@link BackForwardCacheSettings#setTimeoutSeconds(long)}
     */
    public static final String BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3 =
            "BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V3";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link BackForwardCacheSettings#setKeepForwardEntriesEnabled(boolean)}
     * {@link BackForwardCacheSettings#isKeepForwardEntriesEnabled()}
     */
    @WebSettingsCompat.ExperimentalBackForwardCacheSettings
    public static final String BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V4 =
            "BACK_FORWARD_CACHE_SETTINGS_EXPERIMENTAL_V4";


    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, PrefetchParameters, WebViewOutcomeReceiver)}
     * {@link PrefetchCache#prefetchUrlAsync(String, CancellationSignal, Executor, WebViewOutcomeReceiver)}
     */
    @Profile.ExperimentalUrlPrefetch
    public static final String PROFILE_URL_PREFETCH = "PREFETCH_URL_V5";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#setDefaultTrafficStatsTag(int)}}
     */
    public static final String DEFAULT_TRAFFICSTATS_TAGGING = "DEFAULT_TRAFFICSTATS_TAGGING";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebStorageCompat#deleteBrowsingData(WebStorage, Executor, Runnable)},
     * {@link WebStorageCompat#deleteBrowsingData(WebStorage, Runnable)},
     * {@link WebStorageCompat#deleteBrowsingDataForSite(WebStorage, String, Executor, Runnable)},
     * {@link WebStorageCompat#deleteBrowsingDataForSite(WebStorage, String, Runnable)}
     */
    public static final String DELETE_BROWSING_DATA = "DELETE_BROWSING_DATA";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link androidx.webkit.WebViewCompat#prerenderUrlAsync(WebView, String, CancellationSignal, Executor, PrerenderOperationCallback)}
     */
    public static final String PRERENDER_WITH_URL = "PRERENDER_URL_V2";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#setSpeculativeLoadingConfig(SpeculativeLoadingConfig)}
     */
    @Profile.ExperimentalUrlPrefetch
    public static final String SPECULATIVE_LOADING_CONFIG = "SPECULATIVE_LOADING_CONFIG_V2";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link PrefetchCache#setMaxPrefetches(int)}, {@link PrefetchCache#setPrefetchTtlSeconds(int)}
     */
    @Profile.ExperimentalUrlPrefetch
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final String PREFETCH_CACHE_V1 = "PREFETCH_CACHE_V1";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#setMaxPrerenders(int)}
     */
    @Profile.ExperimentalUrlPrefetch
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final String SET_MAX_PRERENDERS_V1 = "SET_MAX_PRERENDERS_V1";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link WebViewCompat#saveState}.
     */
    public static final String SAVE_STATE = "SAVE_STATE";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String NAVIGATION_CALLBACK_BASIC = "WEB_VIEW_NAVIGATION_CLIENT_BASIC_USAGE";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String NAVIGATION_LISTENER_V1 = "NAVIGATION_LISTENER_V1";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String NAVIGATION_LISTENER_V2 = "NAVIGATION_LISTENER_V2";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String NAVIGATION_LISTENER_ON_COMPLETED_FIRES_FOR_NON_COMMITTED =
            "NAVIGATION_LISTENER_ON_COMPLETED_FIRES_FOR_NON_COMMITTED";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String NAVIGATION_LISTENER_NON_NULL_PAGE_FOR_SAME_DOCUMENT_NAVIGATIONS =
            "NAVIGATION_LISTENER_NON_NULL_PAGE_FOR_SAME_DOCUMENT_NAVIGATIONS";

    /**
     * @deprecated Use {@link #NAVIGATION_LISTENER} instead.
     */
    @Deprecated
    public static final String PAGE_GET_URL = "PAGE_GET_URL";

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers
     * {@link Navigation#getWebResourceError()}
     * {@link WebResourceErrorCompat#getDebugCode()}.
     */
    public static final String NAVIGATION_GET_WEB_RESOURCE_ERROR =
            "NAVIGATION_GET_WEB_RESOURCE_ERROR";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link NavigationListener#onNavigationStarted(Navigation)},
     * {@link NavigationListener#onNavigationRedirected(Navigation)},
     * {@link NavigationListener#onNavigationCompleted(Navigation)},
     * {@link NavigationListener#onPageDeleted(Page)},
     * {@link NavigationListener#onPageLoadEvent(Page)},
     * {@link NavigationListener#onPageDomContentLoadedEvent(Page)},
     * {@link NavigationListener#onFirstContentfulPaintMillis(Page, long)},
     * {@link NavigationListener#onLargestContentfulPaintMillis(Page, long)},
     * {@link NavigationListener#onPerformanceMarkMillis(Page, String, long)},
     * {@link Navigation#getPage()},
     * {@link Navigation#getUrl()},
     * {@link Navigation#wasInitiatedByPage()},
     * {@link Navigation#isSameDocument()},
     * {@link Navigation#isReload()},
     * {@link Navigation#isHistory()},
     * {@link Navigation#isBack()},
     * {@link Navigation#isForward()},
     * {@link Navigation#didCommit()},
     * {@link Navigation#didCommitErrorPage()},
     * {@link Navigation#getStatusCode()},
     * {@link Navigation#isRestore()},
     * {@link Page#getUrl()}
     */
    public static final String NAVIGATION_LISTENER = "NAVIGATION_LISTENER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebSettingsCompat#setPaymentRequestEnabled(WebSettings, boolean)},
     * {@link WebSettingsCompat#getPaymentRequestEnabled(WebSettings)},
     * {@link WebSettingsCompat#setHasEnrolledInstrumentEnabled(WebSettings, boolean)}, and
     * {@link WebSettingsCompat#getHasEnrolledInstrumentEnabled(WebSettings)},
     */
    public static final String PAYMENT_REQUEST = "PAYMENT_REQUEST";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers:
     * {@link WebViewBuilder#build(Context)}.
     */
    @WebViewBuilder.Experimental
    public static final String WEBVIEW_BUILDER_EXPERIMENTAL_V1 = "WEBVIEW_BUILDER_EXPERIMENTAL_V1";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers:
     * {@link WebViewBuilder#applyTo(WebView)}.
     */
    @WebViewBuilder.Experimental
    public static final String WEBVIEW_BUILDER_EXPERIMENTAL_V2 =
            "WEBVIEW_BUILDER_EXPERIMENTAL_V2";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link WebResourceResponseCompat#setCookies(List)}, as well as
     * {@link WebSettingsCompat#setCookiesIncludedInShouldInterceptRequest(WebSettings, boolean)}
     * and
     * {@link ServiceWorkerWebSettingsCompat#setIncludeCookiesOnShouldInterceptRequestEnabled(boolean)}.
     */
    public static final String COOKIE_INTERCEPT = "COOKIE_INTERCEPT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link Profile#warmUpRendererProcess}.
     */
    @Profile.ExperimentalWarmUpRendererProcess
    public static final String WARM_UP_RENDERER_PROCESS = "WARM_UP_RENDERER_PROCESS";

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     *
     * <p>This feature covers
     * {@link Profile#addCustomHeader(androidx.webkit.CustomHeader)},
     * {@link Profile#hasCustomHeader(String)},
     * {@link Profile#getCustomHeaders()},
     * {@link Profile#getCustomHeaders(String)},
     * {@link Profile#getCustomHeaders(String, String)},
     * {@link Profile#clearCustomHeader(String)},
     * {@link Profile#clearCustomHeader(String, String)}, and
     * {@link Profile#clearAllCustomHeaders()}.
     */
    public static final String CUSTOM_REQUEST_HEADERS = "CUSTOM_REQUEST_HEADERS";

    /**
     * Feature for {@link WebViewFeature#isFeatureSupported(String)}.
     * This feature covers {@link WebViewStartUpConfig.Builder#setProfilesToLoadDuringStartup(Set)}.
     */
    public static final String STARTUP_FEATURE_SET_PROFILES_TO_LOAD =
            "STARTUP_FEATURE_SET_PROFILES_TO_LOAD";

    /**
     * Feature for {@link #isStartupFeatureSupported(Context, String)}.
     * This feature covers
     * {@link ProcessGlobalConfig#setUiThreadStartupMode(Context, int)}.
     *
     * @deprecated Use {@link #STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2} instead.
     */
    @WebViewCompat.ExperimentalAsyncStartUp
    @Deprecated
    public static final String STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE =
            "STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE";

    /**
     * Feature for {@link #isStartupFeatureSupported(Context, String)}.
     * This feature covers
     * {@link ProcessGlobalConfig#setUiThreadStartupMode(Context, int)}.
     */
    @WebViewCompat.ExperimentalAsyncStartUp
    public static final String STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2 =
            "STARTUP_FEATURE_SET_UI_THREAD_STARTUP_MODE_V2";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link Profile#preconnect(String)}
     */
    @Profile.ExperimentalPreconnect
    public static final String PRECONNECT = "PRECONNECT";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers {@link Profile#enqueuePreconnect(String)}
     */
    @Profile.ExperimentalPreconnect
    public static final String ENQUEUE_PRECONNECT = "ENQUEUE_PRECONNECT";

    /**
     * Feature for {@link Profile#addQuicHints(Set)}.
     */
    @Profile.ExperimentalAddQuicHints
    public static final String ADD_QUIC_HINTS_V1 = "ADD_QUIC_HINTS";

    /**
     * This feature covers
     * {@link WebSettingsCompat#setHyperlinkContextMenuItems(WebSettings, int)},
     */
    public static final String HYPERLINK_CONTEXT_MENU_ITEMS = "HYPERLINK_CONTEXT_MENU_ITEMS";

    /**
     * This is an internal only feature that indicate whether it is safe to cache WebView Provider
     * objects for the current WebView APK.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static final String PROVIDER_WEAKLY_REF_WEBVIEW = "PROVIDER_WEAKLY_REF_WEBVIEW";

    /**
     * Feature for injecting JavaScript into isolated worlds and iFrames.
     * This feature covers:
     * {@link WebViewCompat#addJavaScriptOnEvent(WebView, String, int, Set, JavaScriptExecutionWorld)},
     * {@link WebViewCompat#addWebMessageListener(WebView, String, Set, JavaScriptExecutionWorld, WebViewCompat.WebMessageListener)},
     * {@link WebViewCompat#removeWebMessageListener(WebView, JavaScriptExecutionWorld, String)}
     * {@link WebViewCompat#getExecutionWorld(WebView, String)}, and
     * {@link JavaScriptReplyProxy#executeJavaScript(String, WebViewOutcomeReceiver)}.
     */
    public static final String JS_INJECTION_IN_FRAME_AND_WORLD = "JS_INJECTION_IN_FRAME_AND_WORLD";

    /**
     * This feature covers
     * {@link WebViewCompat#navigate(WebView, String, NavigationParameters)}.
     */
    @WebViewCompat.ExperimentalNavigate
    public static final String WEBVIEW_NAVIGATE_EXPERIMENTAL_V1 =
            "WEBVIEW_NAVIGATE_EXPERIMENTAL_V1";

    /**
     * When this feature is enabled,
     * {@link WebViewCompat#navigate(WebView, String, NavigationParameters)}
     * will drain the prefetch queue before navigating.
     * <p>
     * This will become the default behavior of
     * {@link WebViewCompat#navigate(WebView, String, NavigationParameters)}.
     */
    @WebViewCompat.ExperimentalNavigate
    public static final String WEBVIEW_NAVIGATE_DRAIN_PREFETCH =
            "WEBVIEW_NAVIGATE_DRAIN_PREFETCH";

    /**
     * Feature for
     * {@link WebSettingsCompat#setDownloadFaviconsEnabled(WebSettings, boolean)},
     * {@link WebSettingsCompat#getDownloadFaviconsEnabled(WebSettings)}
     */
    public static final String DOWNLOAD_FAVICONS_ENABLED = "DOWNLOAD_FAVICONS_ENABLED";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#getHttpCache()}
     * {@link HttpCache#getDefaultQuotaBytes()}
     * {@link HttpCache#isUsingDefaultQuota()}
     * {@link HttpCache#useDefaultQuota()}
     * {@link HttpCache#getQuotaBytes()}
     * {@link HttpCache#setQuotaBytes(long)}
     */
    public static final String HTTP_CACHE_MANAGER = "HTTP_CACHE_MANAGER";

    /**
     * Feature for {@link #isFeatureSupported(String)}.
     * This feature covers
     * {@link Profile#setCrossOriginIsolatedAllowlist(Set)}
     * {@link Profile#getCrossOriginIsolatedAllowlist()}
     */
    public static final String CROSS_ORIGIN_ISOLATED_ALLOWLIST =
            "CROSS_ORIGIN_ISOLATED_ALLOWLIST";

    /**
     * Return whether a feature is supported at run-time. This will check whether a feature is
     * supported, depending on the combination of the desired feature, the Android version of
     * device, and the WebView APK on the device.
     *
     * <p class="note"><b>Note:</b> This method is different from
     * {@link WebViewFeature#isStartupFeatureSupported(Context, String)} and this method only
     * accepts certain features. Please verify that the correct feature checking method is used for
     * a particular feature.
     *
     * <p class="note"><b>Note:</b> If this method returns {@code false}, it is not safe to invoke
     * the methods requiring the desired feature. Furthermore, if this method returns {@code false}
     * for a particular feature, any callback guarded by that feature will not be invoked.
     *
     * @param feature the feature to be checked
     * @return whether the feature is supported given the current platform SDK and WebView version
     */
    public static boolean isFeatureSupported(@WebViewSupportFeature @NonNull String feature) {
        return WebViewFeatureInternal.isSupported(feature);
    }

    /**
     * Return whether a startup feature is supported at run-time. This will check whether a startup
     * feature is
     * supported, depending on the combination of the desired feature, the Android version of
     * device, and the WebView APK on the device.
     *
     * <p class="note"><b>Note:</b> This method is different from
     * {@link #isFeatureSupported(String)} and this method only accepts startup features. Please
     * verify that the correct feature checking method is used for a particular feature.
     *
     * <p class="note"><b>Note:</b> If this method returns {@code false}, it is not safe to invoke
     * the methods requiring the desired feature. Furthermore, if this method returns {@code false}
     * for a particular feature, any callback guarded by that feature will not be invoked.
     *
     * @param context        a Context to access application assets This value cannot be null.
     * @param startupFeature the startup feature to be checked
     * @return whether the feature is supported given the current platform SDK and WebView version
     */
    public static boolean isStartupFeatureSupported(@NonNull Context context,
            @WebViewStartupFeature @NonNull String startupFeature) {
        return WebViewFeatureInternal.isStartupFeatureSupported(startupFeature, context);
    }

}
