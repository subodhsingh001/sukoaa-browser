# v7.4.16 (Sun Sep 27 2026)

#### :scroll: Update Public Suffix List

- Updates [#2691](https://github.com/remusao/tldts/pull/2691) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.6 (Thu Jul 02 2026)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 25.9.1 to 26.1.0 [#2627](https://github.com/remusao/tldts/pull/2627) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.1.2 (Sun May 24 2026)

#### :nail_care: Polish

- Security-review hardening: IPv6 hextet validation, build-time guard, docs & dep audit [#2587](https://github.com/remusao/tldts/pull/2587) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.1.0 (Sat May 23 2026)

#### :running_woman: Performance

- Better performance and reduce memory allocations [#2585](https://github.com/remusao/tldts/pull/2585) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.25 (Fri Mar 06 2026)

#### :nut_and_bolt: Dependencies

- Bump nyc from 17.1.0 to 18.0.0 [#2517](https://github.com/remusao/tldts/pull/2517) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.0.22 (Tue Feb 03 2026)

#### :nut_and_bolt: Dependencies

- Bump chai from 4.5.0 to 6.2.2 [#2482](https://github.com/remusao/tldts/pull/2482) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- chore: upgrade dependencies [#2498](https://github.com/remusao/tldts/pull/2498) ([@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.21 (Sun Feb 01 2026)

#### :scroll: Update Public Suffix List

- Update PSL + dependencies [#2497](https://github.com/remusao/tldts/pull/2497) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.20 (Sat Jan 31 2026)

#### ⚠️ Pushed to `master`

- Bump to Yarn 4 and try to fix publishing. ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.13 (Sat Sep 06 2025)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 22.14.1 to 24.3.1 [#2415](https://github.com/remusao/tldts/pull/2415) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.81 (Sat Mar 01 2025)

#### :scroll: Update Public Suffix List

- Make sure internal packages are also present on npmjs [#2289](https://github.com/remusao/tldts/pull/2289) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.3 (Sat Apr 08 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1598](https://github.com/remusao/tldts/pull/1598) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))
