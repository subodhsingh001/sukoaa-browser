# v7.4.16 (Sun Sep 27 2026)

#### :scroll: Update Public Suffix List

- Updates [#2691](https://github.com/remusao/tldts/pull/2691) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.12 (Mon Sep 07 2026)

#### :nut_and_bolt: Dependencies

- Bump mocha from 11.7.6 to 12.0.0 [#2669](https://github.com/remusao/tldts/pull/2669) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.4.6 (Thu Jul 02 2026)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 25.9.1 to 26.1.0 [#2627](https://github.com/remusao/tldts/pull/2627) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.3.1 (Mon May 25 2026)

#### :bug: Bug Fix

- fix: reject hostname labels that begin with a hyphen (#2395) [#2591](https://github.com/remusao/tldts/pull/2591) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.3.0 (Mon May 25 2026)

#### :running_woman: Performance

- perf(core): validate hostname inline during extraction to drop a redundant scan [#2590](https://github.com/remusao/tldts/pull/2590) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.2.1 (Mon May 25 2026)

#### :nail_care: Polish

- fix: extract unbracketed IPv6 hostnames instead of mangling them [#2589](https://github.com/remusao/tldts/pull/2589) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.2.0 (Mon May 25 2026)

#### :rocket: New Feature

- feat: add opt-in IANA special-use domain detection [#2588](https://github.com/remusao/tldts/pull/2588) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.1.2 (Sun May 24 2026)

#### :nail_care: Polish

- Security-review hardening: IPv6 hextet validation, build-time guard, docs & dep audit [#2587](https://github.com/remusao/tldts/pull/2587) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.1.1 (Sun May 24 2026)

#### :nail_care: Polish

- fix: make hostname extraction match WHATWG URL host boundaries [#2586](https://github.com/remusao/tldts/pull/2586) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.1.0 (Sat May 23 2026)

#### :running_woman: Performance

- Better performance and reduce memory allocations [#2585](https://github.com/remusao/tldts/pull/2585) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.32 (Sat May 23 2026)

#### :bug: Bug Fix

- fix: accept labels ending with an underscore [#2583](https://github.com/remusao/tldts/pull/2583) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.25 (Fri Mar 06 2026)

#### :nut_and_bolt: Dependencies

- Bump nyc from 17.1.0 to 18.0.0 [#2517](https://github.com/remusao/tldts/pull/2517) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.0.22 (Tue Feb 03 2026)

#### :nut_and_bolt: Dependencies

- Bump chai from 4.5.0 to 6.2.2 [#2482](https://github.com/remusao/tldts/pull/2482) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- chore: upgrade dependencies [#2498](https://github.com/remusao/tldts/pull/2498) ([@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.21 (Sun Feb 01 2026)

#### :scroll: Update Public Suffix List

- Update PSL + dependencies [#2497](https://github.com/remusao/tldts/pull/2497) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.20 (Sat Jan 31 2026)

#### ⚠️ Pushed to `master`

- Bump to Yarn 4 and try to fix publishing. ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.13 (Sat Sep 06 2025)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 22.14.1 to 24.3.1 [#2415](https://github.com/remusao/tldts/pull/2415) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v7.0.0 (Sat Apr 12 2025)

#### :boom: Breaking Change

- Fix inconsistent hostname validation in `getHostname` and `parse(url).hostname` when `validateHostname` is enabled [#2262](https://github.com/remusao/tldts/pull/2262) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.69 (Thu Dec 19 2024)

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-node-resolve from 15.3.0 to 16.0.0 [#2235](https://github.com/remusao/tldts/pull/2235) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.68 (Sat Dec 14 2024)

#### :nut_and_bolt: Dependencies

- Bump mocha from 10.8.2 to 11.0.1 [#2229](https://github.com/remusao/tldts/pull/2229) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.48 (Fri Sep 27 2024)

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-typescript from 11.1.6 to 12.1.0 [#2161](https://github.com/remusao/tldts/pull/2161) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.36 (Mon Jul 29 2024)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 20.14.12 to 22.0.0 [#2115](https://github.com/remusao/tldts/pull/2115) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.26 (Fri Jun 14 2024)

#### :nut_and_bolt: Dependencies

- Bump nyc from 15.1.0 to 17.0.0 [#2062](https://github.com/remusao/tldts/pull/2062) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.1.13 (Thu Mar 07 2024)

#### :bug: Bug Fix

- Fixes [#1978](https://github.com/remusao/tldts/pull/1978) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.17 (Sun Oct 22 2023)

#### :nut_and_bolt: Dependencies

- Bump rollup from 3.29.1 to 4.1.0 [#1817](https://github.com/remusao/tldts/pull/1817) ([@dependabot[bot]](https://github.com/dependabot[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.6 (Fri Jun 16 2023)

#### :nut_and_bolt: Dependencies

- Bump rimraf from 4.4.1 to 5.0.1 [#1654](https://github.com/remusao/tldts/pull/1654) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 18.16.3 to 20.2.3 [#1658](https://github.com/remusao/tldts/pull/1658) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v6.0.3 (Sat Apr 08 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1598](https://github.com/remusao/tldts/pull/1598) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.0 (Sat Apr 01 2023)

### Release Notes

#### Be more lenient in accepting leading underscores and dots in hostnames ([#1553](https://github.com/remusao/tldts/pull/1553))

Handling of _leading dot(s)_ in input URIs and hostnames:

```patch
- expect(isValidHostname('.github.com')).to.equal(false);
+ expect(isValidHostname('.github.com')).to.equal(true);

- expect(getDomain('.github.com')).to.equal(null);
+ expect(getDomain('.github.com')).to.equal('github.com');

- expect(getDomain('.remusao.github.io')).to.equal(null);
+ expect(getDomain('.remusao.github.io')).to.equal('github.io');
```

Handling of _leading underscores_ in input URIs and hostnames:

```patch
- expect(getDomain('_0f6879.bsg-1418.bryanjswift.com')).to.equal(null);
+ expect(getDomain('_0f6879.bsg-1418.bryanjswift.com')).to.equal('bryanjswift.com');
```

Lastly, increase test coverage using test cases found in the [whatwg](https://url.spec.whatwg.org/#host-miscellaneous) spec.

This is a breaking change because some might rely on the previous behavior to consider leading dots and underscores as invalid hostnames or domains.

Resolves #1534
Resolves #1523

#### tooling: migrate to eslint + TypeScript v5 + prettier ([#1575](https://github.com/remusao/tldts/pull/1575))

Updated internal representation of the DAWG used to encode the public suffix list, resulting in ~5% size reduction of minified bundle for identical performance (and likely a faster parsing/loading time of the source, although I did not measure that particular aspect yet).

Migrate from deprecated `tslint` to eslint with TypeScript support and fix most of the issues encountered, resulting in tighter typing. Bump TypeScript to v5 as well and make sure code-base is formatted according to prettier's preset.

---

#### :boom: Breaking Change

- Be more lenient in accepting leading underscores and dots in hostnames [#1553](https://github.com/remusao/tldts/pull/1553) ([@remusao](https://github.com/remusao))

#### :house: Internal

- tooling: migrate to eslint + TypeScript v5 + prettier [#1575](https://github.com/remusao/tldts/pull/1575) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.110 (Wed Mar 01 2023)

#### :house: Internal

- Update deprecated dep and refresh lock [#1554](https://github.com/remusao/tldts/pull/1554) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.105 (Thu Feb 02 2023)

#### :nut_and_bolt: Dependencies

- Bump rimraf from 3.0.2 to 4.1.2 [#1525](https://github.com/remusao/tldts/pull/1525) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @rollup/plugin-typescript from 10.0.1 to 11.0.0 [#1515](https://github.com/remusao/tldts/pull/1515) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.102 (Thu Dec 01 2022)

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-typescript from 9.0.2 to 10.0.0 [#1484](https://github.com/remusao/tldts/pull/1484) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.98 (Sat Nov 05 2022)

#### :house: Internal

- Dependencies updates [#1464](https://github.com/remusao/tldts/pull/1464) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/mocha from 9.1.1 to 10.0.0 [#1443](https://github.com/remusao/tldts/pull/1443) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.92 (Sat Sep 24 2022)

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-node-resolve from 13.3.0 to 14.1.0 [#1431](https://github.com/remusao/tldts/pull/1431) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.87 (Tue Aug 02 2022)

#### :nail_care: Polish

- Add index.ts as part of published packages [#1398](https://github.com/remusao/tldts/pull/1398) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.85 (Sun Jul 31 2022)

#### :nail_care: Polish

- Include 'src' folder as part of published packages [#1396](https://github.com/remusao/tldts/pull/1396) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.83 (Wed Jun 29 2022)

#### :nut_and_bolt: Dependencies

- Bump mocha from 9.2.2 to 10.0.0 [#1327](https://github.com/remusao/tldts/pull/1327) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 17.0.41 to 18.0.0 [#1364](https://github.com/remusao/tldts/pull/1364) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.59 (Fri Jan 21 2022)

#### :nut_and_bolt: Dependencies

- Bump @types/node from 16.11.11 to 17.0.8 [#1244](https://github.com/remusao/tldts/pull/1244) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.39 (Thu Aug 05 2021)

#### :nut_and_bolt: Dependencies

- Bump @types/mocha from 8.2.3 to 9.0.0 [#1125](https://github.com/remusao/tldts/pull/1125) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 15.12.4 to 16.3.2 [#1118](https://github.com/remusao/tldts/pull/1118) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump mocha from 8.4.0 to 9.0.0 [#1088](https://github.com/remusao/tldts/pull/1088) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 1

- [@dependabot[bot]](https://github.com/dependabot[bot])

---

# v5.7.38 (Sun May 30 2021)

#### :scroll: Update Public Suffix List

- Bump deps + GitHub actions + update rules [#1079](https://github.com/remusao/tldts/pull/1079) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.35 (Tue May 11 2021)

#### :house: Internal

- Refresh yarn.lock + updates [#1059](https://github.com/remusao/tldts/pull/1059) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.32 (Wed Apr 28 2021)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @types/node from 14.14.41 to 15.0.1 [#1044](https://github.com/remusao/tldts/pull/1044) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.7.0 (Fri Jan 22 2021)

#### :rocket: New Feature

- Migrate to using Terser [#893](https://github.com/remusao/tldts/pull/893) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.74 (Wed Dec 02 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 10.0.0 to 11.0.0 [#838](https://github.com/remusao/tldts/pull/838) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.62 (Thu Oct 29 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 9.0.0 to 10.0.0 [#797](https://github.com/remusao/tldts/pull/797) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.51 (Tue Aug 25 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump typescript from 3.9.7 to 4.0.2 [#729](https://github.com/remusao/tldts/pull/729) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.49 (Fri Aug 14 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 8.4.0 to 9.0.0 [#714](https://github.com/remusao/tldts/pull/714) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.39 (Tue Jul 14 2020)

#### :nut_and_bolt: Dependencies

- chore(deps): bump @types/mocha from 7.0.2 to 8.0.0 [#667](https://github.com/remusao/tldts/pull/667) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.31 (Thu Jun 11 2020)

#### :nut_and_bolt: Dependencies

- chore(deps): bump mocha from 7.2.0 to 8.0.1 [#634](https://github.com/remusao/tldts/pull/634) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.26 (Sat May 23 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 7.1.3 to 8.0.0 [#588](https://github.com/remusao/tldts/pull/588) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- chore(deps-dev): bump @types/node from 13.13.5 to 14.0.0 [#571](https://github.com/remusao/tldts/pull/571) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.25 (Wed May 06 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump rollup-plugin-sourcemaps from 0.5.0 to 0.6.1 [#555](https://github.com/remusao/tldts/pull/555) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.24 (Fri Apr 24 2020)

#### :house: Internal

- Migrate from jest to mocha + chai [#525](https://github.com/remusao/tldts/pull/525) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.21 (Mon Apr 06 2020)

#### :bug: Bug Fix

- Fix handling of data URLs [#502](https://github.com/remusao/tldts/pull/502) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.11 (Wed Mar 11 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump rollup from 1.32.1 to 2.0.0 [#421](https://github.com/remusao/tldts/pull/421) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.8 (Wed Feb 19 2020)

#### :scroll: Update Public Suffix List

- Fix CHANGELOG titles [skip ci] ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.4 (Sun Feb 16 2020)

#### :scroll: Update Public Suffix List

- Release v5.6.3 ([@remusao](https://github.com/remusao))
- Release v5.6.2 ([@remusao](https://github.com/remusao))
- Release v5.6.1 ([@remusao](https://github.com/remusao))
- fix: handling of ipv6 when 'extractHostname' option is 'false' ([@remusao](https://github.com/remusao))
- chore(deps-dev): bump @types/node from 12.12.21 to 13.1.0

Bumps [@types/node](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/HEAD/types/node) from 12.12.21 to 13.1.0.

- [Release notes](https://github.com/DefinitelyTyped/DefinitelyTyped/releases)
- [Commits](https://github.com/DefinitelyTyped/DefinitelyTyped/commits/HEAD/types/node)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump rollup-plugin-sourcemaps from 0.4.2 to 0.5.0

Bumps [rollup-plugin-sourcemaps](https://github.com/maxdavidson/rollup-plugin-sourcemaps) from 0.4.2 to 0.5.0.

- [Release notes](https://github.com/maxdavidson/rollup-plugin-sourcemaps/releases)
- [Changelog](https://github.com/maxdavidson/rollup-plugin-sourcemaps/blob/master/CHANGELOG.md)
- [Commits](https://github.com/maxdavidson/rollup-plugin-sourcemaps/compare/v0.4.2...v0.5.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- chore(deps): bump @types/jest from 24.9.1 to 25.1.0

Bumps [@types/jest](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/HEAD/types/jest) from 24.9.1 to 25.1.0.

- [Release notes](https://github.com/DefinitelyTyped/DefinitelyTyped/releases)
- [Commits](https://github.com/DefinitelyTyped/DefinitelyTyped/commits/HEAD/types/jest)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#361](https://github.com/remusao/tldts/pull/361) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps): bump ts-jest from 24.3.0 to 25.0.0

Bumps [ts-jest](https://github.com/kulshekhar/ts-jest) from 24.3.0 to 25.0.0.

- [Release notes](https://github.com/kulshekhar/ts-jest/releases)
- [Changelog](https://github.com/kulshekhar/ts-jest/blob/master/CHANGELOG.md)
- [Commits](https://github.com/kulshekhar/ts-jest/compare/v24.3.0...v25.0.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#358](https://github.com/remusao/tldts/pull/358) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps): bump jest from 24.9.0 to 25.1.0

Bumps [jest](https://github.com/facebook/jest) from 24.9.0 to 25.1.0.

- [Release notes](https://github.com/facebook/jest/releases)
- [Changelog](https://github.com/facebook/jest/blob/master/CHANGELOG.md)
- [Commits](https://github.com/facebook/jest/compare/v24.9.0...v25.1.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#353](https://github.com/remusao/tldts/pull/353) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump tslint from 5.20.1 to 6.0.0

Bumps [tslint](https://github.com/palantir/tslint) from 5.20.1 to 6.0.0.

- [Release notes](https://github.com/palantir/tslint/releases)
- [Changelog](https://github.com/palantir/tslint/blob/master/CHANGELOG.md)
- [Commits](https://github.com/palantir/tslint/compare/5.20.1...6.0.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#355](https://github.com/remusao/tldts/pull/355) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 2

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- Rémi ([@remusao](https://github.com/remusao))
