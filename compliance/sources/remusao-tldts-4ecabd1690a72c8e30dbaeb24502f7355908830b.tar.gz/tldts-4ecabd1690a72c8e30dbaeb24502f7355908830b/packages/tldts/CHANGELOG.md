# v7.4.19 (Tue Oct 20 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2718](https://github.com/remusao/tldts/pull/2718) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.17 (Wed Oct 07 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2708](https://github.com/remusao/tldts/pull/2708) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.16 (Sun Sep 27 2026)

#### :scroll: Update Public Suffix List

- Updates [#2691](https://github.com/remusao/tldts/pull/2691) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.15 (Wed Sep 23 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2685](https://github.com/remusao/tldts/pull/2685) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.14 (Mon Sep 21 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2680](https://github.com/remusao/tldts/pull/2680) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.13 (Sun Sep 13 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2673](https://github.com/remusao/tldts/pull/2673) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.12 (Mon Sep 07 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2666](https://github.com/remusao/tldts/pull/2666) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump mocha from 11.7.6 to 12.0.0 [#2669](https://github.com/remusao/tldts/pull/2669) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.11 (Mon Aug 24 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2655](https://github.com/remusao/tldts/pull/2655) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.10 (Thu Jul 30 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2639](https://github.com/remusao/tldts/pull/2639) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.9 (Thu Jul 16 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2636](https://github.com/remusao/tldts/pull/2636) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.8 (Thu Jul 09 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2632](https://github.com/remusao/tldts/pull/2632) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.7 (Tue Jul 07 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2630](https://github.com/remusao/tldts/pull/2630) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.6 (Thu Jul 02 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2626](https://github.com/remusao/tldts/pull/2626) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 25.9.1 to 26.1.0 [#2627](https://github.com/remusao/tldts/pull/2627) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.5 (Sun Jun 28 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2617](https://github.com/remusao/tldts/pull/2617) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.4 (Tue Jun 23 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2614](https://github.com/remusao/tldts/pull/2614) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.3 (Mon Jun 15 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2605](https://github.com/remusao/tldts/pull/2605) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.2 (Sat May 30 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2597](https://github.com/remusao/tldts/pull/2597) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.1 (Sat May 30 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2595](https://github.com/remusao/tldts/pull/2595) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.4.0 (Mon May 25 2026)

#### :rocket: New Feature

- feat: add getFullDomain to return the full hostname incl. subdomain (#2322) [#2592](https://github.com/remusao/tldts/pull/2592) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.2.0 (Mon May 25 2026)

#### :rocket: New Feature

- feat: add opt-in IANA special-use domain detection [#2588](https://github.com/remusao/tldts/pull/2588) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.1.0 (Sat May 23 2026)

#### :running_woman: Performance

- Better performance and reduce memory allocations [#2585](https://github.com/remusao/tldts/pull/2585) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.31 (Sat May 23 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2567](https://github.com/remusao/tldts/pull/2567) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.30 (Sat May 02 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2563](https://github.com/remusao/tldts/pull/2563) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.29 (Tue Apr 28 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2550](https://github.com/remusao/tldts/pull/2550) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.28 (Sat Apr 04 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2541](https://github.com/remusao/tldts/pull/2541) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.27 (Fri Mar 20 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2534](https://github.com/remusao/tldts/pull/2534) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.26 (Mon Mar 16 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2525](https://github.com/remusao/tldts/pull/2525) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.25 (Fri Mar 06 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2522](https://github.com/remusao/tldts/pull/2522) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump nyc from 17.1.0 to 18.0.0 [#2517](https://github.com/remusao/tldts/pull/2517) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @rollup/plugin-terser from 0.4.4 to 1.0.0 [#2523](https://github.com/remusao/tldts/pull/2523) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.24 (Mon Mar 02 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2506](https://github.com/remusao/tldts/pull/2506) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.23 (Sun Feb 08 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2502](https://github.com/remusao/tldts/pull/2502) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.22 (Tue Feb 03 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2500](https://github.com/remusao/tldts/pull/2500) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump chai from 4.5.0 to 6.2.2 [#2482](https://github.com/remusao/tldts/pull/2482) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- chore: upgrade dependencies [#2498](https://github.com/remusao/tldts/pull/2498) ([@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.21 (Sun Feb 01 2026)

#### :scroll: Update Public Suffix List

- Update PSL + dependencies [#2497](https://github.com/remusao/tldts/pull/2497) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.20 (Sat Jan 31 2026)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2472](https://github.com/remusao/tldts/pull/2472) ([@remusao](https://github.com/remusao))

#### ⚠️ Pushed to `master`

- Bump to Yarn 4 and try to fix publishing. ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.19 (Sat Nov 22 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2468](https://github.com/remusao/tldts/pull/2468) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.18 (Mon Nov 17 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2452](https://github.com/remusao/tldts/pull/2452) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.17 (Thu Oct 09 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2431](https://github.com/remusao/tldts/pull/2431) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.16 (Mon Sep 22 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2430](https://github.com/remusao/tldts/pull/2430) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.15 (Sat Sep 20 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2425](https://github.com/remusao/tldts/pull/2425) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.14 (Thu Sep 11 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2417](https://github.com/remusao/tldts/pull/2417) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.13 (Sat Sep 06 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2406](https://github.com/remusao/tldts/pull/2406) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 22.14.1 to 24.3.1 [#2415](https://github.com/remusao/tldts/pull/2415) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.12 (Tue Aug 19 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2401](https://github.com/remusao/tldts/pull/2401) ([@remusao](https://github.com/remusao))

#### :memo: Documentation

- correct example for domain.unknown in README.md [#2399](https://github.com/remusao/tldts/pull/2399) ([@jkennedyphlo](https://github.com/jkennedyphlo))

#### Authors: 2

- [@jkennedyphlo](https://github.com/jkennedyphlo)
- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.11 (Tue Aug 05 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2379](https://github.com/remusao/tldts/pull/2379) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.10 (Wed Jul 02 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2372](https://github.com/remusao/tldts/pull/2372) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.9 (Wed Jun 18 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2353](https://github.com/remusao/tldts/pull/2353) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.8 (Fri May 30 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2340](https://github.com/remusao/tldts/pull/2340) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.7 (Fri May 09 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2338](https://github.com/remusao/tldts/pull/2338) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.6 (Mon May 05 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2332](https://github.com/remusao/tldts/pull/2332) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.5 (Wed Apr 30 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2328](https://github.com/remusao/tldts/pull/2328) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.4 (Fri Apr 25 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2325](https://github.com/remusao/tldts/pull/2325) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.3 (Fri Apr 25 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2324](https://github.com/remusao/tldts/pull/2324) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.2 (Tue Apr 22 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2323](https://github.com/remusao/tldts/pull/2323) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v7.0.1 (Fri Apr 18 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2321](https://github.com/remusao/tldts/pull/2321) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.86 (Sat Apr 12 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2311](https://github.com/remusao/tldts/pull/2311) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.85 (Sat Mar 22 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2302](https://github.com/remusao/tldts/pull/2302) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.84 (Mon Mar 10 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2298](https://github.com/remusao/tldts/pull/2298) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.83 (Thu Mar 06 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2297](https://github.com/remusao/tldts/pull/2297) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.80 (Sat Mar 01 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2287](https://github.com/remusao/tldts/pull/2287) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.79 (Thu Feb 27 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2284](https://github.com/remusao/tldts/pull/2284) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.78 (Thu Feb 20 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2275](https://github.com/remusao/tldts/pull/2275) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.77 (Sat Feb 08 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2273](https://github.com/remusao/tldts/pull/2273) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.76 (Fri Jan 31 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2266](https://github.com/remusao/tldts/pull/2266) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.75 (Sun Jan 26 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2261](https://github.com/remusao/tldts/pull/2261) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.74 (Wed Jan 22 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2254](https://github.com/remusao/tldts/pull/2254) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.73 (Sat Jan 18 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2251](https://github.com/remusao/tldts/pull/2251) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.72 (Wed Jan 15 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2245](https://github.com/remusao/tldts/pull/2245) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.71 (Mon Jan 06 2025)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2241](https://github.com/remusao/tldts/pull/2241) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.70 (Wed Dec 25 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2237](https://github.com/remusao/tldts/pull/2237) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.69 (Thu Dec 19 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2234](https://github.com/remusao/tldts/pull/2234) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-node-resolve from 15.3.0 to 16.0.0 [#2235](https://github.com/remusao/tldts/pull/2235) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.68 (Sat Dec 14 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2233](https://github.com/remusao/tldts/pull/2233) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump mocha from 10.8.2 to 11.0.1 [#2229](https://github.com/remusao/tldts/pull/2229) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.67 (Wed Dec 11 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2231](https://github.com/remusao/tldts/pull/2231) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.66 (Sat Dec 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2228](https://github.com/remusao/tldts/pull/2228) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.65 (Sat Nov 30 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2221](https://github.com/remusao/tldts/pull/2221) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.64 (Sat Nov 23 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2220](https://github.com/remusao/tldts/pull/2220) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.63 (Thu Nov 21 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2218](https://github.com/remusao/tldts/pull/2218) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.62 (Wed Nov 20 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2214](https://github.com/remusao/tldts/pull/2214) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.61 (Wed Nov 13 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2211](https://github.com/remusao/tldts/pull/2211) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.60 (Sun Nov 10 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2209](https://github.com/remusao/tldts/pull/2209) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.59 (Thu Nov 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2205](https://github.com/remusao/tldts/pull/2205) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.58 (Sat Nov 02 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2201](https://github.com/remusao/tldts/pull/2201) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.57 (Tue Oct 29 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2195](https://github.com/remusao/tldts/pull/2195) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.56 (Sat Oct 26 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2192](https://github.com/remusao/tldts/pull/2192) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.55 (Thu Oct 24 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2190](https://github.com/remusao/tldts/pull/2190) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.54 (Tue Oct 22 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2187](https://github.com/remusao/tldts/pull/2187) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.53 (Tue Oct 22 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2183](https://github.com/remusao/tldts/pull/2183) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.52 (Wed Oct 16 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2181](https://github.com/remusao/tldts/pull/2181) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.51 (Sat Oct 12 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2179](https://github.com/remusao/tldts/pull/2179) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.50 (Thu Oct 03 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2174](https://github.com/remusao/tldts/pull/2174) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.49 (Wed Oct 02 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2171](https://github.com/remusao/tldts/pull/2171) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.48 (Fri Sep 27 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2166](https://github.com/remusao/tldts/pull/2166) ([@remusao](https://github.com/remusao))
- Update upstream public suffix list [#2157](https://github.com/remusao/tldts/pull/2157) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-typescript from 11.1.6 to 12.1.0 [#2161](https://github.com/remusao/tldts/pull/2161) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.47 (Thu Sep 19 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2154](https://github.com/remusao/tldts/pull/2154) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.46 (Sun Sep 15 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2152](https://github.com/remusao/tldts/pull/2152) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.45 (Fri Sep 13 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2149](https://github.com/remusao/tldts/pull/2149) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.44 (Tue Sep 10 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2147](https://github.com/remusao/tldts/pull/2147) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.43 (Sat Sep 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2146](https://github.com/remusao/tldts/pull/2146) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.42 (Thu Sep 05 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2137](https://github.com/remusao/tldts/pull/2137) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.41 (Thu Aug 22 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2135](https://github.com/remusao/tldts/pull/2135) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.40 (Mon Aug 19 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2127](https://github.com/remusao/tldts/pull/2127) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.39 (Sat Aug 10 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2125](https://github.com/remusao/tldts/pull/2125) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.38 (Mon Aug 05 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2122](https://github.com/remusao/tldts/pull/2122) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.37 (Wed Jul 31 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2116](https://github.com/remusao/tldts/pull/2116) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.36 (Mon Jul 29 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2113](https://github.com/remusao/tldts/pull/2113) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 20.14.12 to 22.0.0 [#2115](https://github.com/remusao/tldts/pull/2115) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.35 (Fri Jul 26 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2110](https://github.com/remusao/tldts/pull/2110) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.34 (Tue Jul 23 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2106](https://github.com/remusao/tldts/pull/2106) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.33 (Sat Jul 20 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2102](https://github.com/remusao/tldts/pull/2102) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.32 (Wed Jul 17 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2097](https://github.com/remusao/tldts/pull/2097) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.31 (Sun Jul 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2084](https://github.com/remusao/tldts/pull/2084) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.30 (Thu Jun 27 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2079](https://github.com/remusao/tldts/pull/2079) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.29 (Sat Jun 22 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2076](https://github.com/remusao/tldts/pull/2076) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.28 (Thu Jun 20 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2068](https://github.com/remusao/tldts/pull/2068) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.27 (Mon Jun 17 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2067](https://github.com/remusao/tldts/pull/2067) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.26 (Fri Jun 14 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2063](https://github.com/remusao/tldts/pull/2063) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump nyc from 15.1.0 to 17.0.0 [#2062](https://github.com/remusao/tldts/pull/2062) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.25 (Thu Jun 06 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2057](https://github.com/remusao/tldts/pull/2057) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.23 (Tue May 28 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2051](https://github.com/remusao/tldts/pull/2051) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.22 (Sun May 26 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2049](https://github.com/remusao/tldts/pull/2049) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.21 (Tue May 21 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2040](https://github.com/remusao/tldts/pull/2040) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.20 (Mon May 13 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2035](https://github.com/remusao/tldts/pull/2035) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.19 (Sat May 04 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2031](https://github.com/remusao/tldts/pull/2031) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.18 (Fri Apr 19 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2021](https://github.com/remusao/tldts/pull/2021) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.17 (Fri Apr 19 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#2015](https://github.com/remusao/tldts/pull/2015) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.16 (Fri Mar 29 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1998](https://github.com/remusao/tldts/pull/1998) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.15 (Wed Mar 27 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1996](https://github.com/remusao/tldts/pull/1996) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.14 (Thu Mar 21 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1992](https://github.com/remusao/tldts/pull/1992) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.13 (Thu Mar 07 2024)

#### :bug: Bug Fix

- Fixes [#1978](https://github.com/remusao/tldts/pull/1978) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.12 (Thu Mar 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1973](https://github.com/remusao/tldts/pull/1973) ([@remusao](https://github.com/remusao))
- Update upstream public suffix list [#1972](https://github.com/remusao/tldts/pull/1972) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.11 (Tue Feb 13 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1959](https://github.com/remusao/tldts/pull/1959) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.10 (Thu Feb 08 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1952](https://github.com/remusao/tldts/pull/1952) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.9 (Tue Feb 06 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1951](https://github.com/remusao/tldts/pull/1951) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.8 (Sun Feb 04 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1947](https://github.com/remusao/tldts/pull/1947) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.7 (Sat Feb 03 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1946](https://github.com/remusao/tldts/pull/1946) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.6 (Fri Feb 02 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1945](https://github.com/remusao/tldts/pull/1945) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.5 (Fri Feb 02 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1941](https://github.com/remusao/tldts/pull/1941) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.4 (Sat Jan 27 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1937](https://github.com/remusao/tldts/pull/1937) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.3 (Wed Jan 24 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1933](https://github.com/remusao/tldts/pull/1933) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.2 (Sun Jan 07 2024)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1912](https://github.com/remusao/tldts/pull/1912) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.1 (Thu Dec 14 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1890](https://github.com/remusao/tldts/pull/1890) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.1.0 (Tue Dec 05 2023)

#### :rocket: New Feature

- Add new tldts-icann package which does not contain private rules [#1888](https://github.com/remusao/tldts/pull/1888) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.22 (Mon Nov 27 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1868](https://github.com/remusao/tldts/pull/1868) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.21 (Tue Nov 21 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1857](https://github.com/remusao/tldts/pull/1857) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.19 (Sun Nov 05 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1841](https://github.com/remusao/tldts/pull/1841) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.18 (Thu Nov 02 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1833](https://github.com/remusao/tldts/pull/1833) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.17 (Sun Oct 22 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1828](https://github.com/remusao/tldts/pull/1828) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump rollup from 3.29.1 to 4.1.0 [#1817](https://github.com/remusao/tldts/pull/1817) ([@dependabot[bot]](https://github.com/dependabot[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.16 (Fri Oct 06 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1787](https://github.com/remusao/tldts/pull/1787) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.15 (Sat Sep 23 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1744](https://github.com/remusao/tldts/pull/1744) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.14 (Thu Aug 10 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1732](https://github.com/remusao/tldts/pull/1732) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.13 (Sun Jul 30 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1727](https://github.com/remusao/tldts/pull/1727) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.12 (Sat Jul 22 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1717](https://github.com/remusao/tldts/pull/1717) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.11 (Mon Jul 10 2023)

#### :bug: Bug Fix

- bug: fix for https://github.com/remusao/tldts/issues/1697 [#1709](https://github.com/remusao/tldts/pull/1709) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.10 (Mon Jul 10 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1700](https://github.com/remusao/tldts/pull/1700) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.9 (Sat Jul 01 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1698](https://github.com/remusao/tldts/pull/1698) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.8 (Sun Jun 18 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1682](https://github.com/remusao/tldts/pull/1682) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.7 (Sat Jun 17 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1681](https://github.com/remusao/tldts/pull/1681) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.6 (Fri Jun 16 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1640](https://github.com/remusao/tldts/pull/1640) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump rimraf from 4.4.1 to 5.0.1 [#1654](https://github.com/remusao/tldts/pull/1654) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 18.16.3 to 20.2.3 [#1658](https://github.com/remusao/tldts/pull/1658) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.5 (Tue May 09 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1633](https://github.com/remusao/tldts/pull/1633) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.4 (Tue May 02 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1606](https://github.com/remusao/tldts/pull/1606) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.3 (Sat Apr 08 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1598](https://github.com/remusao/tldts/pull/1598) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.2 (Mon Apr 03 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1594](https://github.com/remusao/tldts/pull/1594) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v6.0.0 (Sat Apr 01 2023)

### Release Notes

#### Be more lenient in accepting leading underscores and dots in hostnames ([#1553](https://github.com/remusao/tldts/pull/1553))

Handling of _leading dot(s)_ in input URIs and hostnames:

```patch
- expect(isValidHostname('.github.com')).to.equal(false);
+ expect(isValidHostname('.github.com')).to.equal(true);

- expect(getDomain('.github.com')).to.equal(null);
+ expect(getDomain('.github.com')).to.equal('github.com');

- expect(getDomain('.remusao.github.io')).to.equal(null);
+ expect(getDomain('.remusao.github.io')).to.equal('github.io');
```

Handling of _leading underscores_ in input URIs and hostnames:

```patch
- expect(getDomain('_0f6879.bsg-1418.bryanjswift.com')).to.equal(null);
+ expect(getDomain('_0f6879.bsg-1418.bryanjswift.com')).to.equal('bryanjswift.com');
```

Lastly, increase test coverage using test cases found in the [whatwg](https://url.spec.whatwg.org/#host-miscellaneous) spec.

This is a breaking change because some might rely on the previous behavior to consider leading dots and underscores as invalid hostnames or domains.

Resolves #1534
Resolves #1523

#### tooling: migrate to eslint + TypeScript v5 + prettier ([#1575](https://github.com/remusao/tldts/pull/1575))

Updated internal representation of the DAWG used to encode the public suffix list, resulting in ~5% size reduction of minified bundle for identical performance (and likely a faster parsing/loading time of the source, although I did not measure that particular aspect yet).

Migrate from deprecated `tslint` to eslint with TypeScript support and fix most of the issues encountered, resulting in tighter typing. Bump TypeScript to v5 as well and make sure code-base is formatted according to prettier's preset.

---

#### :boom: Breaking Change

- Be more lenient in accepting leading underscores and dots in hostnames [#1553](https://github.com/remusao/tldts/pull/1553) ([@remusao](https://github.com/remusao))

#### :house: Internal

- tooling: migrate to eslint + TypeScript v5 + prettier [#1575](https://github.com/remusao/tldts/pull/1575) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.112 (Sun Mar 19 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1574](https://github.com/remusao/tldts/pull/1574) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.111 (Wed Mar 08 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1566](https://github.com/remusao/tldts/pull/1566) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.110 (Wed Mar 01 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1555](https://github.com/remusao/tldts/pull/1555) ([@remusao](https://github.com/remusao))

#### :house: Internal

- Update deprecated dep and refresh lock [#1554](https://github.com/remusao/tldts/pull/1554) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.109 (Wed Feb 15 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1545](https://github.com/remusao/tldts/pull/1545) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.108 (Sat Feb 11 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1540](https://github.com/remusao/tldts/pull/1540) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.107 (Fri Feb 10 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1538](https://github.com/remusao/tldts/pull/1538) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.106 (Wed Feb 08 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1536](https://github.com/remusao/tldts/pull/1536) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.105 (Thu Feb 02 2023)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1521](https://github.com/remusao/tldts/pull/1521) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump rimraf from 3.0.2 to 4.1.2 [#1525](https://github.com/remusao/tldts/pull/1525) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @rollup/plugin-typescript from 10.0.1 to 11.0.0 [#1515](https://github.com/remusao/tldts/pull/1515) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.103 (Mon Dec 19 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1497](https://github.com/remusao/tldts/pull/1497) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.102 (Thu Dec 01 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1489](https://github.com/remusao/tldts/pull/1489) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-typescript from 9.0.2 to 10.0.0 [#1484](https://github.com/remusao/tldts/pull/1484) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.101 (Wed Nov 23 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1483](https://github.com/remusao/tldts/pull/1483) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.100 (Tue Nov 15 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1480](https://github.com/remusao/tldts/pull/1480) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.99 (Mon Nov 07 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1476](https://github.com/remusao/tldts/pull/1476) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.98 (Sat Nov 05 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1475](https://github.com/remusao/tldts/pull/1475) ([@remusao](https://github.com/remusao))

#### :house: Internal

- Dependencies updates [#1464](https://github.com/remusao/tldts/pull/1464) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/mocha from 9.1.1 to 10.0.0 [#1443](https://github.com/remusao/tldts/pull/1443) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.97 (Fri Oct 14 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1457](https://github.com/remusao/tldts/pull/1457) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.96 (Fri Oct 14 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1456](https://github.com/remusao/tldts/pull/1456) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.95 (Tue Oct 11 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1453](https://github.com/remusao/tldts/pull/1453) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.94 (Fri Oct 07 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1449](https://github.com/remusao/tldts/pull/1449) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.93 (Tue Oct 04 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1440](https://github.com/remusao/tldts/pull/1440) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.92 (Sat Sep 24 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1434](https://github.com/remusao/tldts/pull/1434) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @rollup/plugin-node-resolve from 13.3.0 to 14.1.0 [#1431](https://github.com/remusao/tldts/pull/1431) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.90 (Fri Aug 26 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1417](https://github.com/remusao/tldts/pull/1417) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.89 (Thu Aug 11 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1404](https://github.com/remusao/tldts/pull/1404) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.88 (Sun Aug 07 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1395](https://github.com/remusao/tldts/pull/1395) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.87 (Tue Aug 02 2022)

#### :nail_care: Polish

- Add index.ts as part of published packages [#1398](https://github.com/remusao/tldts/pull/1398) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.85 (Sun Jul 31 2022)

#### :nail_care: Polish

- Include 'src' folder as part of published packages [#1396](https://github.com/remusao/tldts/pull/1396) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.83 (Wed Jun 29 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1369](https://github.com/remusao/tldts/pull/1369) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump mocha from 9.2.2 to 10.0.0 [#1327](https://github.com/remusao/tldts/pull/1327) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 17.0.41 to 18.0.0 [#1364](https://github.com/remusao/tldts/pull/1364) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.79 (Mon May 16 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1334](https://github.com/remusao/tldts/pull/1334) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.78 (Wed May 11 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1332](https://github.com/remusao/tldts/pull/1332) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.76 (Sat Apr 16 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1313](https://github.com/remusao/tldts/pull/1313) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.75 (Fri Apr 08 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1311](https://github.com/remusao/tldts/pull/1311) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.74 (Thu Mar 31 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1309](https://github.com/remusao/tldts/pull/1309) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.73 (Sat Mar 26 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1306](https://github.com/remusao/tldts/pull/1306) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.71 (Mon Mar 21 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1302](https://github.com/remusao/tldts/pull/1302) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.69 (Sun Mar 06 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1292](https://github.com/remusao/tldts/pull/1292) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.68 (Sat Mar 05 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1289](https://github.com/remusao/tldts/pull/1289) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.67 (Mon Feb 28 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1285](https://github.com/remusao/tldts/pull/1285) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.66 (Wed Feb 23 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1283](https://github.com/remusao/tldts/pull/1283) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.65 (Sat Feb 19 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1279](https://github.com/remusao/tldts/pull/1279) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.64 (Sat Feb 19 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1278](https://github.com/remusao/tldts/pull/1278) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.63 (Tue Feb 15 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1277](https://github.com/remusao/tldts/pull/1277) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.62 (Sun Feb 13 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1275](https://github.com/remusao/tldts/pull/1275) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.61 (Fri Feb 04 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1266](https://github.com/remusao/tldts/pull/1266) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.60 (Sat Jan 29 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1265](https://github.com/remusao/tldts/pull/1265) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.59 (Fri Jan 21 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1254](https://github.com/remusao/tldts/pull/1254) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/node from 16.11.11 to 17.0.8 [#1244](https://github.com/remusao/tldts/pull/1244) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.58 (Mon Jan 03 2022)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1236](https://github.com/remusao/tldts/pull/1236) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.57 (Thu Dec 16 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1222](https://github.com/remusao/tldts/pull/1222) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.56 (Tue Dec 07 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1221](https://github.com/remusao/tldts/pull/1221) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.55 (Sun Dec 05 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1220](https://github.com/remusao/tldts/pull/1220) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.54 (Sun Dec 05 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1217](https://github.com/remusao/tldts/pull/1217) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.52 (Wed Nov 10 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1208](https://github.com/remusao/tldts/pull/1208) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.51 (Mon Nov 08 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1206](https://github.com/remusao/tldts/pull/1206) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.50 (Fri Oct 29 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1203](https://github.com/remusao/tldts/pull/1203) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.49 (Mon Oct 18 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1192](https://github.com/remusao/tldts/pull/1192) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.48 (Thu Oct 14 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1183](https://github.com/remusao/tldts/pull/1183) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.47 (Tue Sep 28 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1182](https://github.com/remusao/tldts/pull/1182) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.46 (Sun Sep 26 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1178](https://github.com/remusao/tldts/pull/1178) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.45 (Tue Sep 21 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1175](https://github.com/remusao/tldts/pull/1175) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.44 (Fri Sep 17 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1168](https://github.com/remusao/tldts/pull/1168) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.43 (Sun Sep 05 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1164](https://github.com/remusao/tldts/pull/1164) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.42 (Fri Sep 03 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1163](https://github.com/remusao/tldts/pull/1163) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.41 (Fri Aug 27 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1148](https://github.com/remusao/tldts/pull/1148) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.40 (Fri Aug 06 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1143](https://github.com/remusao/tldts/pull/1143) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.39 (Thu Aug 05 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1140](https://github.com/remusao/tldts/pull/1140) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- Bump @types/mocha from 8.2.3 to 9.0.0 [#1125](https://github.com/remusao/tldts/pull/1125) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump @types/node from 15.12.4 to 16.3.2 [#1118](https://github.com/remusao/tldts/pull/1118) ([@dependabot[bot]](https://github.com/dependabot[bot]))
- Bump mocha from 8.4.0 to 9.0.0 [#1088](https://github.com/remusao/tldts/pull/1088) ([@dependabot[bot]](https://github.com/dependabot[bot]))

#### Authors: 2

- [@dependabot[bot]](https://github.com/dependabot[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.38 (Sun May 30 2021)

#### :scroll: Update Public Suffix List

- Bump deps + GitHub actions + update rules [#1079](https://github.com/remusao/tldts/pull/1079) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.37 (Wed May 19 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1066](https://github.com/remusao/tldts/pull/1066) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.36 (Tue May 18 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1065](https://github.com/remusao/tldts/pull/1065) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.35 (Tue May 11 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1060](https://github.com/remusao/tldts/pull/1060) ([@remusao](https://github.com/remusao))

#### :house: Internal

- Refresh yarn.lock + updates [#1059](https://github.com/remusao/tldts/pull/1059) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.34 (Thu May 06 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1055](https://github.com/remusao/tldts/pull/1055) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.33 (Sat May 01 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1050](https://github.com/remusao/tldts/pull/1050) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.32 (Wed Apr 28 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1046](https://github.com/remusao/tldts/pull/1046) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @types/node from 14.14.41 to 15.0.1 [#1044](https://github.com/remusao/tldts/pull/1044) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 2

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.31 (Tue Apr 27 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1041](https://github.com/remusao/tldts/pull/1041) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.30 (Tue Apr 27 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1040](https://github.com/remusao/tldts/pull/1040) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.29 (Fri Apr 23 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1039](https://github.com/remusao/tldts/pull/1039) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.28 (Thu Apr 22 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1038](https://github.com/remusao/tldts/pull/1038) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.27 (Mon Apr 19 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1035](https://github.com/remusao/tldts/pull/1035) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.26 (Sun Apr 18 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1034](https://github.com/remusao/tldts/pull/1034) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.25 (Wed Apr 07 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1025](https://github.com/remusao/tldts/pull/1025) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.24 (Mon Apr 05 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1024](https://github.com/remusao/tldts/pull/1024) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.23 (Sat Apr 03 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1023](https://github.com/remusao/tldts/pull/1023) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.22 (Fri Apr 02 2021)

#### :nail_care: Polish

- CLI: process each line of STDIN if no agruments are passed, fixes #1009 [#1021](https://github.com/remusao/tldts/pull/1021) ([@fulldecent](https://github.com/fulldecent) [@remusao](https://github.com/remusao))

#### Authors: 2

- Rémi ([@remusao](https://github.com/remusao))
- William Entriken ([@fulldecent](https://github.com/fulldecent))

---

# v5.7.21 (Thu Apr 01 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1020](https://github.com/remusao/tldts/pull/1020) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.20 (Tue Mar 30 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1019](https://github.com/remusao/tldts/pull/1019) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.19 (Sun Mar 28 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1015](https://github.com/remusao/tldts/pull/1015) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.18 (Fri Mar 26 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1005](https://github.com/remusao/tldts/pull/1005) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.17 (Mon Mar 22 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#1002](https://github.com/remusao/tldts/pull/1002) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.16 (Thu Mar 18 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#990](https://github.com/remusao/tldts/pull/990) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.15 (Sun Mar 14 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#983](https://github.com/remusao/tldts/pull/983) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.14 (Sat Mar 13 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#977](https://github.com/remusao/tldts/pull/977) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.11 (Wed Mar 03 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#958](https://github.com/remusao/tldts/pull/958) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.10 (Wed Feb 24 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#946](https://github.com/remusao/tldts/pull/946) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.9 (Sun Feb 21 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#944](https://github.com/remusao/tldts/pull/944) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.8 (Thu Feb 18 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#939](https://github.com/remusao/tldts/pull/939) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.7 (Tue Feb 16 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#936](https://github.com/remusao/tldts/pull/936) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.6 (Fri Feb 12 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#933](https://github.com/remusao/tldts/pull/933) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.5 (Thu Feb 11 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#926](https://github.com/remusao/tldts/pull/926) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.4 (Wed Feb 10 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#921](https://github.com/remusao/tldts/pull/921) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.2 (Fri Jan 29 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#901](https://github.com/remusao/tldts/pull/901) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.1 (Mon Jan 25 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#897](https://github.com/remusao/tldts/pull/897) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.7.0 (Fri Jan 22 2021)

#### :rocket: New Feature

- Migrate to using Terser [#893](https://github.com/remusao/tldts/pull/893) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.85 (Fri Jan 22 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#889](https://github.com/remusao/tldts/pull/889) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.84 (Tue Jan 19 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#883](https://github.com/remusao/tldts/pull/883) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.83 (Thu Jan 14 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#875](https://github.com/remusao/tldts/pull/875) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.81 (Sat Jan 09 2021)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#870](https://github.com/remusao/tldts/pull/870) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.79 (Fri Dec 18 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#859](https://github.com/remusao/tldts/pull/859) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.78 (Thu Dec 17 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#858](https://github.com/remusao/tldts/pull/858) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.77 (Tue Dec 15 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#857](https://github.com/remusao/tldts/pull/857) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.76 (Sat Dec 12 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#851](https://github.com/remusao/tldts/pull/851) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.75 (Fri Dec 11 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#848](https://github.com/remusao/tldts/pull/848) ([@remusao](https://github.com/remusao))

#### Authors: 1

- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.74 (Wed Dec 02 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#839](https://github.com/remusao/tldts/pull/839) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 10.0.0 to 11.0.0 [#838](https://github.com/remusao/tldts/pull/838) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 2

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.73 (Sun Nov 22 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#832](https://github.com/remusao/tldts/pull/832) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.72 (Wed Nov 18 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#828](https://github.com/remusao/tldts/pull/828) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.70 (Wed Nov 11 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#823](https://github.com/remusao/tldts/pull/823) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.69 (Tue Nov 10 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#821](https://github.com/remusao/tldts/pull/821) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.68 (Sat Nov 07 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#819](https://github.com/remusao/tldts/pull/819) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.67 (Fri Nov 06 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#817](https://github.com/remusao/tldts/pull/817) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.65 (Tue Nov 03 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#810](https://github.com/remusao/tldts/pull/810) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.64 (Fri Oct 30 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#803](https://github.com/remusao/tldts/pull/803) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.63 (Thu Oct 29 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#801](https://github.com/remusao/tldts/pull/801) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.62 (Thu Oct 29 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 9.0.0 to 10.0.0 [#797](https://github.com/remusao/tldts/pull/797) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.61 (Tue Oct 27 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#794](https://github.com/remusao/tldts/pull/794) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.60 (Wed Oct 14 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#780](https://github.com/remusao/tldts/pull/780) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.59 (Tue Oct 13 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#778](https://github.com/remusao/tldts/pull/778) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.57 (Fri Oct 09 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#777](https://github.com/remusao/tldts/pull/777) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.56 (Fri Oct 09 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#762](https://github.com/remusao/tldts/pull/762) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.54 (Wed Sep 09 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#751](https://github.com/remusao/tldts/pull/751) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.53 (Sat Sep 05 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#747](https://github.com/remusao/tldts/pull/747) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.52 (Fri Aug 28 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#739](https://github.com/remusao/tldts/pull/739) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.51 (Tue Aug 25 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#735](https://github.com/remusao/tldts/pull/735) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump typescript from 3.9.7 to 4.0.2 [#729](https://github.com/remusao/tldts/pull/729) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.50 (Mon Aug 17 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#725](https://github.com/remusao/tldts/pull/725) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.49 (Fri Aug 14 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#718](https://github.com/remusao/tldts/pull/718) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 8.4.0 to 9.0.0 [#714](https://github.com/remusao/tldts/pull/714) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.48 (Tue Aug 11 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#710](https://github.com/remusao/tldts/pull/710) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.46 (Tue Aug 04 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#703](https://github.com/remusao/tldts/pull/703) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.45 (Wed Jul 29 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#696](https://github.com/remusao/tldts/pull/696) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.43 (Tue Jul 21 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#681](https://github.com/remusao/tldts/pull/681) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.42 (Sat Jul 18 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#680](https://github.com/remusao/tldts/pull/680) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.41 (Fri Jul 17 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#677](https://github.com/remusao/tldts/pull/677) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.40 (Thu Jul 16 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#673](https://github.com/remusao/tldts/pull/673) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.39 (Tue Jul 14 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#672](https://github.com/remusao/tldts/pull/672) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps): bump @types/mocha from 7.0.2 to 8.0.0 [#667](https://github.com/remusao/tldts/pull/667) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.38 (Sat Jun 27 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#651](https://github.com/remusao/tldts/pull/651) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.37 (Sat Jun 27 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#650](https://github.com/remusao/tldts/pull/650) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.33 (Sun Jun 14 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#637](https://github.com/remusao/tldts/pull/637) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.32 (Fri Jun 12 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#636](https://github.com/remusao/tldts/pull/636) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.31 (Thu Jun 11 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#635](https://github.com/remusao/tldts/pull/635) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps): bump mocha from 7.2.0 to 8.0.1 [#634](https://github.com/remusao/tldts/pull/634) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.30 (Sat Jun 06 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler [#617](https://github.com/remusao/tldts/pull/617) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.29 (Thu May 28 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#609](https://github.com/remusao/tldts/pull/609) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.28 (Thu May 28 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#605](https://github.com/remusao/tldts/pull/605) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.27 (Wed May 27 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#603](https://github.com/remusao/tldts/pull/603) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.26 (Sat May 23 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#598](https://github.com/remusao/tldts/pull/598) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @rollup/plugin-node-resolve from 7.1.3 to 8.0.0 [#588](https://github.com/remusao/tldts/pull/588) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- chore(deps-dev): bump @types/node from 13.13.5 to 14.0.0 [#571](https://github.com/remusao/tldts/pull/571) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.25 (Wed May 06 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump rollup-plugin-sourcemaps from 0.5.0 to 0.6.1 [#555](https://github.com/remusao/tldts/pull/555) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.24 (Fri Apr 24 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#542](https://github.com/remusao/tldts/pull/542) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :house: Internal

- Migrate from jest to mocha + chai [#525](https://github.com/remusao/tldts/pull/525) ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler [#522](https://github.com/remusao/tldts/pull/522) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.23 (Thu Apr 09 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#516](https://github.com/remusao/tldts/pull/516) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.22 (Tue Apr 07 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#507](https://github.com/remusao/tldts/pull/507) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.20 (Sat Apr 04 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#496](https://github.com/remusao/tldts/pull/496) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.19 (Thu Apr 02 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#487](https://github.com/remusao/tldts/pull/487) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.18 (Wed Apr 01 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#481](https://github.com/remusao/tldts/pull/481) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.17 (Mon Mar 30 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#474](https://github.com/remusao/tldts/pull/474) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.16 (Sun Mar 29 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#469](https://github.com/remusao/tldts/pull/469) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.15 (Thu Mar 26 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#462](https://github.com/remusao/tldts/pull/462) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.14 (Sun Mar 22 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#456](https://github.com/remusao/tldts/pull/456) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.13 (Sat Mar 21 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#452](https://github.com/remusao/tldts/pull/452) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.12 (Sun Mar 15 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#445](https://github.com/remusao/tldts/pull/445) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.11 (Wed Mar 11 2020)

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler [#422](https://github.com/remusao/tldts/pull/422) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))
- chore(deps-dev): bump rollup from 1.32.1 to 2.0.0 [#421](https://github.com/remusao/tldts/pull/421) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 1

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])

---

# v5.6.10 (Tue Mar 03 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#407](https://github.com/remusao/tldts/pull/407) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.22.2 to 0.23.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/commits)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#402](https://github.com/remusao/tldts/pull/402) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.8 (Wed Feb 19 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#385](https://github.com/remusao/tldts/pull/385) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))
- Fix CHANGELOG titles [skip ci] ([@remusao](https://github.com/remusao))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.21.0 to 0.22.2.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/commits)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#378](https://github.com/remusao/tldts/pull/378) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 3

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.7 (Sun Feb 16 2020)

#### :scroll: Update Public Suffix List

- Update upstream public suffix list [#376](https://github.com/remusao/tldts/pull/376) ([@github-actions[bot]](https://github.com/github-actions[bot]) [@remusao](https://github.com/remusao))

#### Authors: 2

- [@github-actions[bot]](https://github.com/github-actions[bot])
- Rémi ([@remusao](https://github.com/remusao))

---

# v5.6.4 (Sun Feb 16 2020)

#### :scroll: Update Public Suffix List

- Release v5.6.3 ([@remusao](https://github.com/remusao))
- Release v5.6.2 ([@remusao](https://github.com/remusao))
- Release v5.6.1 ([@remusao](https://github.com/remusao))
- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.18.1 to 0.19.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.18.1...v0.19.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.16.0 to 0.18.1.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.16.0...v0.18.1)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @types/node from 12.12.21 to 13.1.0

Bumps [@types/node](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/HEAD/types/node) from 12.12.21 to 13.1.0.

- [Release notes](https://github.com/DefinitelyTyped/DefinitelyTyped/releases)
- [Commits](https://github.com/DefinitelyTyped/DefinitelyTyped/commits/HEAD/types/node)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.15.0 to 0.16.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.15.0...v0.16.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.13.0 to 0.15.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.13.0...v0.15.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.12.2 to 0.13.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.12.2...v0.13.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- Bump @ampproject/rollup-plugin-closure-compiler from 0.10.0 to 0.12.0

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.10.0 to 0.12.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.10.0...v0.12.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump rollup-plugin-sourcemaps from 0.4.2 to 0.5.0

Bumps [rollup-plugin-sourcemaps](https://github.com/maxdavidson/rollup-plugin-sourcemaps) from 0.4.2 to 0.5.0.

- [Release notes](https://github.com/maxdavidson/rollup-plugin-sourcemaps/releases)
- [Changelog](https://github.com/maxdavidson/rollup-plugin-sourcemaps/blob/master/CHANGELOG.md)
- [Commits](https://github.com/maxdavidson/rollup-plugin-sourcemaps/compare/v0.4.2...v0.5.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### :nut_and_bolt: Dependencies

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.20.0 to 0.21.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.20.0...v0.21.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#369](https://github.com/remusao/tldts/pull/369) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps): bump @types/jest from 24.9.1 to 25.1.0

Bumps [@types/jest](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/HEAD/types/jest) from 24.9.1 to 25.1.0.

- [Release notes](https://github.com/DefinitelyTyped/DefinitelyTyped/releases)
- [Commits](https://github.com/DefinitelyTyped/DefinitelyTyped/commits/HEAD/types/jest)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#361](https://github.com/remusao/tldts/pull/361) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump @ampproject/rollup-plugin-closure-compiler

Bumps [@ampproject/rollup-plugin-closure-compiler](https://github.com/ampproject/rollup-plugin-closure-compiler) from 0.19.1 to 0.20.0.

- [Release notes](https://github.com/ampproject/rollup-plugin-closure-compiler/releases)
- [Commits](https://github.com/ampproject/rollup-plugin-closure-compiler/compare/v0.19.1...v0.20.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#347](https://github.com/remusao/tldts/pull/347) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps): bump ts-jest from 24.3.0 to 25.0.0

Bumps [ts-jest](https://github.com/kulshekhar/ts-jest) from 24.3.0 to 25.0.0.

- [Release notes](https://github.com/kulshekhar/ts-jest/releases)
- [Changelog](https://github.com/kulshekhar/ts-jest/blob/master/CHANGELOG.md)
- [Commits](https://github.com/kulshekhar/ts-jest/compare/v24.3.0...v25.0.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#358](https://github.com/remusao/tldts/pull/358) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps): bump jest from 24.9.0 to 25.1.0

Bumps [jest](https://github.com/facebook/jest) from 24.9.0 to 25.1.0.

- [Release notes](https://github.com/facebook/jest/releases)
- [Changelog](https://github.com/facebook/jest/blob/master/CHANGELOG.md)
- [Commits](https://github.com/facebook/jest/compare/v24.9.0...v25.1.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#353](https://github.com/remusao/tldts/pull/353) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

- chore(deps-dev): bump tslint from 5.20.1 to 6.0.0

Bumps [tslint](https://github.com/palantir/tslint) from 5.20.1 to 6.0.0.

- [Release notes](https://github.com/palantir/tslint/releases)
- [Changelog](https://github.com/palantir/tslint/blob/master/CHANGELOG.md)
- [Commits](https://github.com/palantir/tslint/compare/5.20.1...6.0.0)

Signed-off-by: dependabot-preview[bot] <support@dependabot.com> [#355](https://github.com/remusao/tldts/pull/355) ([@dependabot-preview[bot]](https://github.com/dependabot-preview[bot]))

#### Authors: 2

- [@dependabot-preview[bot]](https://github.com/dependabot-preview[bot])
- Rémi ([@remusao](https://github.com/remusao))
